
export enum Platform {
  Instagram = 'Instagram',
  TikTok = 'TikTok',
  Facebook = 'Facebook',
  LinkedIn = 'LinkedIn',
  Pinterest = 'Pinterest'
}

export enum ContentType {
  Post = 'Post', // Image + Text
  Reel = 'Reel', // Video + Text
  App = 'App',   // Functional Website/App
  Seo = 'Seo'    // SEO Analysis & Strategy
}

export type ContentTheme = 'Cinematic' | 'Educational' | 'Viral' | 'Product' | 'BehindTheScenes' | 'Minimalist';

export interface SeoAudit {
  score: number;
  titleTag: string;
  metaDescription: string;
  missingTags: string[];
  keywords: string[];
  recommendations: string[];
}

export interface TargetAudience {
  ageGroup: string;
  geo: string;
  interests: string[];
  painPoints: string[];
}

export interface Product {
  name: string;
  description: string;
  imageUrl?: string;
}

export interface BrandProfile {
  url: string;
  name: string;
  description: string;
  industry: string; // e.g. "Real Estate", "Tech", "Fashion"
  knowledgeBase: string; // Detailed services, products, mission
  colors: string[]; // Hex codes
  visualStyle: string; // General style e.g. "Minimalist"
  visualEnvironment?: string; // New: Detailed physical description of the environment (lighting, architecture)
  voice: string; // e.g., "Professional", "Witty", "Empathetic"
  language: string; // e.g. "Swedish", "English"
  logoUrl?: string;
  avatarUrl?: string; // Generated AI Avatar
  targetAudience?: TargetAudience;
  products?: Product[];
  keyElements?: string[]; // Physical descriptors e.g. "Yellow Taxis", "Green Aprons"
  referenceImageUrls?: string[]; // New: List of actual image URLs found on the site
}

export interface ProjectFile {
  name: string;
  language: 'html' | 'css' | 'javascript' | 'json';
  content: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text?: string;
  imageUrl?: string;
  videoUrl?: string;
  // Deprecated: code?: string; 
  projectFiles?: ProjectFile[]; // For multi-file apps
  buildLog?: string[]; // Steps taken during generation
  isLoading?: boolean;
  timestamp: number;
  metadata?: {
    platform: Platform;
    contentType: ContentType;
  };
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  updatedAt: number;
}

export interface CalendarPost {
  id: string;
  date: string; // ISO Date String
  platform: Platform;
  contentType: ContentType;
  title: string;
  caption: string;
  visualPrompt: string;
  status: 'planned' | 'generating' | 'ready';
  mediaUrl?: string;
}

export type ViewMode = 'chat' | 'autopilot';
