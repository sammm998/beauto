import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { 
  SparklesIcon, 
  SendIcon, 
  MenuIcon, 
  PlusIcon, 
  ImageIcon, 
  VideoIcon, 
  InstagramIcon, 
  FacebookIcon, 
  LinkedinIcon,
  DownloadIcon,
  SunIcon,
  MoonIcon,
  SettingsIcon,
  CheckCircle,
  CodeIcon,
  EyeIcon,
  MaximizeIcon,
  XIcon,
  FileIcon,
  FolderIcon,
  ZipIcon,
  ChartIcon,
  RobotIcon
} from './components/Icons';
import { generateSocialCaption, generateImage, generateVideo, generateAppCode, generateSeoAnalysis } from './services/genai';
import { Platform, ContentType, Message, BrandProfile, ProjectFile, ChatSession, ViewMode } from './types';
import { ApiKeyModal } from './components/ApiKeyModal';
import { BrandSettingsModal } from './components/BrandSettingsModal';
import { SocialPreview } from './components/SocialPreviews';
import { SerpPreview } from './components/SeoPreviews';
import { ImageStudioModal } from './components/ImageStudioModal';
import { AutopilotView } from './components/AutopilotView';

// Dynamically import JSZip
// @ts-ignore
import JSZip from 'jszip';

export const App = () => {
  // State
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [viewMode, setViewMode] = useState<ViewMode>('chat');
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  
  const [input, setInput] = useState('');
  const [selectedPlatform, setSelectedPlatform] = useState<Platform>(Platform.Instagram);
  const [selectedContentType, setSelectedContentType] = useState<ContentType>(ContentType.Post);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // App Builder Fullscreen State
  const [fullscreenApp, setFullscreenApp] = useState<ProjectFile[] | null>(null);

  // Modals
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [keyError, setKeyError] = useState<string | undefined>();
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // Image Studio State
  const [editingImage, setEditingImage] = useState<{ url: string, messageId: string } | null>(null);

  // Brand Profile
  const [brandProfile, setBrandProfile] = useState<BrandProfile | undefined>();
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Theme Colors Mapping
  const colors = {
    dark: {
      bg: 'bg-[#131314]',
      text: 'text-[#E3E3E3]',
      sidebar: 'bg-[#1E1F20] border-[#444746]',
      inputBg: 'bg-[#1E1F20]',
      inputBorder: 'border-[#444746]',
      hover: 'hover:bg-[#333]',
      activeItem: 'bg-[#28292A]',
      userMsgBg: 'bg-[#28292A]',
      userMsgText: 'text-white',
      modelMsgText: 'text-gray-200',
      secondaryText: 'text-gray-400',
      scrollThumb: 'bg-[#444746]',
    },
    light: {
      bg: 'bg-white',
      text: 'text-[#1F1F1F]',
      sidebar: 'bg-[#F0F4F9] border-[#E5E7EB]',
      inputBg: 'bg-[#F0F4F9]',
      inputBorder: 'border-transparent',
      hover: 'hover:bg-[#E1E3E1]',
      activeItem: 'bg-[#D3E3FD]',
      userMsgBg: 'bg-[#F0F4F9]',
      userMsgText: 'text-[#1F1F1F]',
      modelMsgText: 'text-[#1F1F1F]',
      secondaryText: 'text-gray-600',
      scrollThumb: 'bg-[#E5E7EB]',
    }
  };

  const t = colors[theme];

  // Initialize first chat if none exist
  useEffect(() => {
    if (sessions.length === 0 && !currentSessionId) {
        createNewChat();
    }
  }, []);

  // Sync messages to current session whenever they change
  useEffect(() => {
    if (currentSessionId) {
        setSessions(prev => prev.map(session => 
            session.id === currentSessionId 
                ? { ...session, messages: messages, updatedAt: Date.now(), title: generateSessionTitle(messages, session.title) } 
                : session
        ));
    }
  }, [messages, currentSessionId]);

  // Scroll to bottom on new message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  const platforms = [
    { id: Platform.Instagram, icon: InstagramIcon, label: 'Instagram' },
    { id: Platform.TikTok, icon: VideoIcon, label: 'TikTok' }, 
    { id: Platform.Facebook, icon: FacebookIcon, label: 'Facebook' },
    { id: Platform.LinkedIn, icon: LinkedinIcon, label: 'LinkedIn' },
    { id: Platform.Pinterest, icon: ImageIcon, label: 'Pinterest' },
  ];

  // --- Session Management ---

  const createNewChat = () => {
    setViewMode('chat');
    const newSession: ChatSession = {
        id: Date.now().toString(),
        title: 'New Chat',
        messages: [],
        updatedAt: Date.now()
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    setMessages([]);
    // Close sidebar on mobile when creating new chat
    if (window.innerWidth < 768) {
        setIsSidebarOpen(false);
    }
  };

  const switchSession = (sessionId: string) => {
      setViewMode('chat');
      const session = sessions.find(s => s.id === sessionId);
      if (session) {
          setCurrentSessionId(sessionId);
          setMessages(session.messages);
          // Close sidebar on mobile
          if (window.innerWidth < 768) {
              setIsSidebarOpen(false);
          }
      }
  };

  const deleteSession = (e: React.MouseEvent, sessionId: string) => {
      e.stopPropagation();
      const updatedSessions = sessions.filter(s => s.id !== sessionId);
      setSessions(updatedSessions);
      
      if (currentSessionId === sessionId) {
          if (updatedSessions.length > 0) {
              // Switch to the first available session
              setCurrentSessionId(updatedSessions[0].id);
              setMessages(updatedSessions[0].messages);
          } else {
              // Create a new empty session if all are deleted
              createNewChat();
          }
      }
  };

  const generateSessionTitle = (msgs: Message[], currentTitle: string) => {
      if (currentTitle !== 'New Chat') return currentTitle;
      if (msgs.length > 0) {
          const firstUserMsg = msgs.find(m => m.role === 'user');
          if (firstUserMsg && firstUserMsg.text) {
              return firstUserMsg.text.slice(0, 30) + (firstUserMsg.text.length > 30 ? '...' : '');
          }
      }
      return 'New Chat';
  }

  // --- Generation Handlers ---

  const handleSend = async () => {
    if (!input.trim() || isProcessing) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: Date.now(),
      metadata: {
        platform: selectedPlatform,
        contentType: selectedContentType
      }
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsProcessing(true);

    // Loading placeholder
    const loadingId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, {
      id: loadingId,
      role: 'model',
      isLoading: true,
      timestamp: Date.now(),
      metadata: {
        platform: selectedPlatform,
        contentType: selectedContentType
      }
    }]);

    try {
      // Logic Branch: Video vs Image vs App vs SEO
      if (selectedContentType === ContentType.Reel) {
        await handleReelGeneration(userMessage.text || '', loadingId);
      } else if (selectedContentType === ContentType.App) {
        await handleAppGeneration(userMessage.text || '', loadingId);
      } else if (selectedContentType === ContentType.Seo) {
        await handleSeoGeneration(userMessage.text || '', loadingId);
      } else {
        await handlePostGeneration(userMessage.text || '', loadingId);
      }
    } catch (error) {
      console.error(error);
      setMessages(prev => prev.map(msg => 
        msg.id === loadingId ? { ...msg, isLoading: false, text: "Sorry, I encountered an error generating your content." } : msg
      ));
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSeoGeneration = async (prompt: string, messageId: string) => {
    try {
      // Direct call, no simulation steps as requested ("precis som chatt")
      const seoReport = await generateSeoAnalysis(prompt, brandProfile);
      
      setMessages(prev => prev.map(msg => 
        msg.id === messageId ? {
          ...msg,
          isLoading: false,
          text: seoReport
        } : msg
      ));
    } catch (e) {
      throw e;
    }
  };

  const handleAppGeneration = async (prompt: string, messageId: string) => {
    // Simulate build steps for UX - Apps still benefit from this visualization
    const steps = [
        "Analyzing requirements...",
        "Structuring architecture...",
        "Writing HTML structure...",
        "Styling with CSS...",
        "Implementing Logic...",
        "Packaging files..."
    ];

    let currentStepIndex = 0;
    const interval = setInterval(() => {
        if (currentStepIndex < steps.length - 1) {
            currentStepIndex++;
            setMessages(prev => prev.map(msg => 
                msg.id === messageId ? {
                    ...msg,
                    buildLog: steps.slice(0, currentStepIndex + 1)
                } : msg
            ));
        }
    }, 1500); // Update step every 1.5s

    try {
        // Find existing app code in history to enable iteration
        // Look backwards for the last message that had project files
        let previousCode: ProjectFile[] | undefined;
        for (let i = messages.length - 1; i >= 0; i--) {
            if (messages[i].projectFiles && messages[i].projectFiles!.length > 0) {
                previousCode = messages[i].projectFiles;
                break;
            }
        }

        const result = await generateAppCode(prompt, brandProfile, previousCode);
        
        let finalFiles = result.files;
        
        // Handle Image Asset Generation
        if (result.imageRequests && result.imageRequests.length > 0) {
            clearInterval(interval);
            // Update UI to show asset generation
            setMessages(prev => prev.map(msg => 
                msg.id === messageId ? {
                    ...msg,
                    buildLog: [...steps, `Generating ${result.imageRequests?.length} visual assets...`]
                } : msg
            ));

            // Generate images in parallel
            const imagePromises = result.imageRequests.map(async (req) => {
                try {
                    const base64 = await generateImage(req.prompt, brandProfile);
                    return { id: req.id, base64 };
                } catch (e) {
                    console.error("Failed to generate asset", req.id);
                    return { id: req.id, base64: null };
                }
            });

            const images = await Promise.all(imagePromises);

            // Inject images into files
            finalFiles = finalFiles.map(file => {
                let content = file.content;
                images.forEach(img => {
                    if (img.base64) {
                        // Replace all occurrences of the placeholder ID with the base64 string
                        // Escaping logic for regex might be needed if ID has special chars, but __IMG__ is safe
                        content = content.split(img.id).join(img.base64);
                    }
                });
                return { ...file, content };
            });
        } else {
             clearInterval(interval);
        }

        setMessages(prev => prev.map(msg => 
            msg.id === messageId ? {
                ...msg,
                isLoading: false,
                projectFiles: finalFiles,
                buildLog: [...steps, "Build & Asset Generation Complete."],
                text: "I've updated the application based on your request. You can preview the changes below."
            } : msg
        ));
    } catch (e) {
        clearInterval(interval);
        throw e;
    }
  };

  const handlePostGeneration = async (prompt: string, messageId: string) => {
    try {
      // Parallel execution: Generate Image (Nano Banana) AND Caption (Flash)
      const [imageUrl, caption] = await Promise.all([
        generateImage(prompt, brandProfile),
        generateSocialCaption(selectedPlatform, ContentType.Post, prompt, brandProfile)
      ]);

      setMessages(prev => prev.map(msg => 
        msg.id === messageId ? {
          ...msg,
          isLoading: false,
          imageUrl: imageUrl || undefined,
          text: caption
        } : msg
      ));
    } catch (e) {
        throw e;
    }
  };

  const handleReelGeneration = async (prompt: string, messageId: string) => {
    // Check for API Key for Veo
    if (window.aistudio) {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (!hasKey) {
        setShowKeyModal(true);
        setMessages(prev => prev.map(msg => 
            msg.id === messageId ? { ...msg, isLoading: false, text: "Please select a paid API key to generate video content." } : msg
        ));
        return;
      }
    }

    try {
        // 1. Generate Video
        const videoUrl = await generateVideo(prompt, brandProfile);
        
        // 2. Generate Caption
        const caption = await generateSocialCaption(selectedPlatform, ContentType.Reel, prompt, brandProfile);

        setMessages(prev => prev.map(msg => 
            msg.id === messageId ? {
            ...msg,
            isLoading: false,
            videoUrl: videoUrl || undefined,
            text: caption
            } : msg
        ));
    } catch (e: any) {
        if (e.message?.includes("Requested entity was not found") && window.aistudio) {
             setMessages(prev => prev.map(msg => 
                msg.id === messageId ? { ...msg, isLoading: false, text: "API Key invalid. Please select a key again." } : msg
            ));
            setShowKeyModal(true);
        } else {
            throw e;
        }
    }
  };

  const onKeySelected = async () => {
      if (window.aistudio) {
          try {
              await window.aistudio.openSelectKey();
              setShowKeyModal(false);
              setKeyError(undefined);
          } catch (e) {
              setKeyError("Failed to select key.");
          }
      }
  };

  const handleDownload = (url: string, type: 'image' | 'video') => {
    const a = document.createElement('a');
    a.href = url;
    a.download = `beauto-${type}-${Date.now()}.${type === 'image' ? 'png' : 'mp4'}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleZipDownload = async (files: ProjectFile[]) => {
      const zip = new JSZip();
      files.forEach(file => {
          zip.file(file.name, file.content);
      });
      const content = await zip.generateAsync({type: "blob"});
      const url = URL.createObjectURL(content);
      
      const a = document.createElement('a');
      a.href = url;
      a.download = `beauto-project-${Date.now()}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
  };

  const handleSaveEditedImage = (newImage: string) => {
    if (editingImage) {
      setMessages(prev => prev.map(msg => 
        msg.id === editingImage.messageId 
          ? { ...msg, imageUrl: newImage } 
          : msg
      ));
    }
  };

  // Live Preview Component (Updated for multi-file)
  const LivePreview = ({ files, buildLog, isLoading }: { files?: ProjectFile[], buildLog?: string[], isLoading?: boolean }) => {
    const [view, setView] = useState<'preview' | 'code'>('preview');
    const [activeFile, setActiveFile] = useState<string>('index.html');

    if (isLoading) {
        return (
            <div className={`mt-4 rounded-xl p-6 border ${theme === 'dark' ? 'border-[#444746] bg-[#1E1F20]' : 'border-gray-200 bg-gray-50'}`}>
                <div className="flex flex-col gap-3">
                    <div className="flex items-center gap-2 mb-2">
                        <div className={`w-4 h-4 rounded-full border-2 border-blue-500 border-t-transparent animate-spin`} />
                        <span className="font-medium text-sm">Beauto AI is thinking...</span>
                    </div>
                    {buildLog?.map((step, idx) => (
                        <div key={idx} className={`text-xs flex items-center gap-2 ${idx === buildLog.length - 1 ? 'text-blue-400' : 'text-gray-500'}`}>
                            <CheckCircle className={`w-3 h-3 ${idx === buildLog.length - 1 ? 'animate-pulse' : ''}`} />
                            {step}
                        </div>
                    ))}
                </div>
            </div>
        );
    }

    if (!files) return null;

    // Combine files for preview
    const htmlContent = files.find(f => f.name === 'index.html')?.content || '';
    const cssContent = files.find(f => f.name === 'styles.css')?.content || '';
    const jsContent = files.find(f => f.name === 'script.js')?.content || '';

    // Inject CSS and JS into HTML for the iframe preview
    const previewDoc = htmlContent
        .replace('</head>', `<style>${cssContent}</style></head>`)
        .replace('</body>', `<script>${jsContent}</script></body>`);

    const currentFileContent = files.find(f => f.name === activeFile)?.content || '';

    return (
        <div className={`mt-4 rounded-xl overflow-hidden border ${theme === 'dark' ? 'border-[#444746]' : 'border-gray-200'} shadow-lg flex flex-col md:flex-row h-[500px]`}>
            {/* Sidebar File Explorer */}
            <div className={`w-full md:w-48 flex flex-col border-b md:border-b-0 md:border-r ${theme === 'dark' ? 'bg-[#1E1F20] border-[#444746]' : 'bg-gray-100 border-gray-200'}`}>
                <div className="p-3 text-xs font-bold uppercase tracking-wider text-gray-500 flex items-center gap-2">
                    <FolderIcon className="w-3.5 h-3.5" />
                    Project Files
                </div>
                <div className="flex-1 overflow-y-auto">
                    {files.map(file => (
                        <button
                            key={file.name}
                            onClick={() => { setActiveFile(file.name); setView('code'); }}
                            className={`w-full text-left px-4 py-2 text-xs flex items-center gap-2 ${
                                activeFile === file.name && view === 'code'
                                    ? (theme === 'dark' ? 'bg-[#333] text-blue-400' : 'bg-white text-blue-600 shadow-sm')
                                    : 'text-gray-500 hover:text-gray-400'
                            }`}
                        >
                            <FileIcon className="w-3.5 h-3.5" />
                            {file.name}
                        </button>
                    ))}
                </div>
                <div className="p-3 border-t border-[#444746]">
                     <button 
                        onClick={() => handleZipDownload(files)}
                        className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-xs py-2 rounded-lg transition-colors"
                     >
                         <ZipIcon className="w-3.5 h-3.5" />
                         Download ZIP
                     </button>
                </div>
            </div>

            {/* Main Area */}
            <div className="flex-1 flex flex-col min-w-0">
                {/* Toolbar */}
                <div className={`flex items-center justify-between px-3 py-2 ${theme === 'dark' ? 'bg-[#1E1F20]' : 'bg-gray-100'} border-b ${theme === 'dark' ? 'border-[#444746]' : 'border-gray-200'}`}>
                    <div className="flex gap-1">
                        <button 
                            onClick={() => setView('preview')}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${view === 'preview' ? (theme === 'dark' ? 'bg-[#333] text-white' : 'bg-white text-black shadow-sm') : 'text-gray-500 hover:text-gray-400'}`}
                        >
                            <EyeIcon className="w-3.5 h-3.5" />
                            Preview
                        </button>
                        <button 
                            onClick={() => setView('code')}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${view === 'code' ? (theme === 'dark' ? 'bg-[#333] text-white' : 'bg-white text-black shadow-sm') : 'text-gray-500 hover:text-gray-400'}`}
                        >
                            <CodeIcon className="w-3.5 h-3.5" />
                            Code
                        </button>
                    </div>
                    <button 
                    onClick={() => setFullscreenApp(files)}
                    className="p-1.5 text-gray-500 hover:text-gray-300 transition-colors"
                    title="Maximize"
                    >
                        <MaximizeIcon className="w-4 h-4" />
                    </button>
                </div>

                {/* Content */}
                <div className={`relative flex-1 ${theme === 'dark' ? 'bg-black' : 'bg-white'}`}>
                    {view === 'preview' ? (
                        <iframe 
                            srcDoc={previewDoc}
                            title="App Preview"
                            className="w-full h-full border-none bg-white"
                            sandbox="allow-scripts allow-same-origin allow-modals"
                        />
                    ) : (
                        <div className="w-full h-full flex flex-col">
                            <div className="px-4 py-1 text-[10px] text-gray-500 border-b border-[#333] bg-[#1a1a1b] font-mono">
                                {activeFile}
                            </div>
                            <pre className={`flex-1 overflow-auto p-4 text-xs font-mono ${theme === 'dark' ? 'text-green-400 bg-[#0d0d0d]' : 'text-gray-800 bg-gray-50'}`}>
                                {currentFileContent}
                            </pre>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
  };

  return (
    <div className={`flex h-screen ${t.bg} ${t.text} overflow-hidden transition-colors duration-300`}>
      
      {/* Fullscreen App Preview Modal */}
      {fullscreenApp && (
          <div className="fixed inset-0 z-[60] bg-black flex flex-col">
              <div className="flex items-center justify-between p-3 bg-[#1E1F20] border-b border-[#444746]">
                  <span className="text-white font-medium text-sm flex items-center gap-2">
                      <CodeIcon className="w-4 h-4 text-blue-400" />
                      App Preview
                  </span>
                  <div className="flex gap-3">
                     <button 
                        onClick={() => handleZipDownload(fullscreenApp)}
                        className="flex items-center gap-2 text-white bg-blue-600 hover:bg-blue-500 px-3 py-1.5 rounded-md text-xs"
                     >
                         <ZipIcon className="w-3.5 h-3.5" />
                         Download ZIP
                     </button>
                     <button onClick={() => setFullscreenApp(null)} className="text-gray-400 hover:text-white p-2">
                        <XIcon className="w-5 h-5" />
                     </button>
                  </div>
              </div>
              <iframe 
                srcDoc={
                    (fullscreenApp.find(f => f.name === 'index.html')?.content || '')
                    .replace('</head>', `<style>${fullscreenApp.find(f => f.name === 'styles.css')?.content || ''}</style></head>`)
                    .replace('</body>', `<script>${fullscreenApp.find(f => f.name === 'script.js')?.content || ''}</script></body>`)
                }
                className="w-full flex-1 border-none bg-white"
                title="Fullscreen Preview"
                sandbox="allow-scripts allow-same-origin allow-modals"
              />
          </div>
      )}

      {/* Modals */}
      <ApiKeyModal 
        isOpen={showKeyModal} 
        onClose={() => setShowKeyModal(false)}
        onSelectKey={onKeySelected}
        error={keyError}
      />
      
      <BrandSettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
        onSave={(profile) => setBrandProfile(profile)}
        currentProfile={brandProfile}
      />

      {/* Image Studio Modal */}
      {editingImage && (
        <ImageStudioModal
            isOpen={!!editingImage}
            onClose={() => setEditingImage(null)}
            originalImage={editingImage.url}
            onSave={handleSaveEditedImage}
        />
      )}

      {/* Sidebar */}
      <div className={`${isSidebarOpen ? 'w-64' : 'w-0'} ${t.sidebar} transition-all duration-300 ease-in-out flex flex-col border-r`}>
        <div className="p-4 flex items-center gap-3">
          <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className={`p-2 rounded-full ${t.hover}`}>
            <MenuIcon className={`w-5 h-5 ${t.secondaryText}`} />
          </button>
          <span className="font-google text-lg opacity-90">Beauto</span>
        </div>
        
        <div className="px-4 py-2 space-y-2">
          <button 
            onClick={createNewChat}
            className={`w-full flex items-center gap-3 px-4 py-3 ${viewMode === 'chat' && theme === 'dark' ? 'bg-[#28292A]' : viewMode === 'chat' ? 'bg-[#D3E3FD]' : 'bg-transparent border border-[#444746]'} ${t.hover} rounded-full transition-colors text-sm font-medium`}
          >
            <PlusIcon className={`w-4 h-4 ${viewMode === 'chat' ? (theme === 'dark' ? 'text-gray-300' : 'text-blue-800') : 'text-gray-500'}`} />
            <span className={viewMode === 'chat' ? (theme === 'dark' ? 'text-gray-300' : 'text-blue-800') : 'text-gray-500'}>New Chat</span>
          </button>
          
          <button 
            onClick={() => { setViewMode('autopilot'); if(window.innerWidth < 768) setIsSidebarOpen(false); }}
            className={`w-full flex items-center gap-3 px-4 py-3 ${viewMode === 'autopilot' ? (theme === 'dark' ? 'bg-[#28292A] text-purple-300' : 'bg-purple-100 text-purple-800') : 'bg-transparent border border-[#444746] text-gray-500'} ${t.hover} rounded-full transition-colors text-sm font-medium`}
          >
            <RobotIcon className={`w-4 h-4 ${viewMode === 'autopilot' ? 'text-purple-400' : 'text-gray-500'}`} />
            <span>Autopilot</span>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
          <p className={`text-xs font-medium ${t.secondaryText} mb-3 ml-2`}>Recent</p>
          <div className="flex flex-col gap-1">
             {sessions.map(session => (
                 <div 
                    key={session.id}
                    onClick={() => switchSession(session.id)}
                    className={`group flex items-center justify-between px-3 py-2 rounded-full cursor-pointer text-sm truncate transition-colors ${
                        currentSessionId === session.id && viewMode === 'chat'
                            ? (theme === 'dark' ? 'bg-[#333] text-white' : 'bg-[#e7f0fe] text-[#1f1f1f]') 
                            : `${t.secondaryText} ${t.hover}`
                    }`}
                 >
                    <span className="truncate flex-1">{session.title}</span>
                    <button 
                        onClick={(e) => deleteSession(e, session.id)}
                        className={`opacity-0 group-hover:opacity-100 p-1 rounded-full hover:bg-red-500/20 hover:text-red-500 transition-all`}
                        title="Delete Chat"
                    >
                        <XIcon className="w-3 h-3" />
                    </button>
                 </div>
             ))}
             
             {sessions.length === 0 && (
                 <p className="text-xs text-gray-500 italic ml-3">No chats yet</p>
             )}
          </div>
        </div>
        
        <div className="p-4 space-y-2">
            {/* Brand Settings Button */}
            <button 
                onClick={() => setShowSettingsModal(true)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg ${t.hover} transition-colors group border ${theme === 'dark' ? 'border-[#333]' : 'border-gray-200'}`}
            >
                <div className="flex items-center gap-2">
                    <SettingsIcon className={`w-4 h-4 ${t.secondaryText}`} />
                    <span className={`text-sm ${t.secondaryText}`}>Brand Settings</span>
                </div>
                {brandProfile && (
                     <CheckCircle className="w-3 h-3 text-green-500" />
                )}
            </button>

           <div className="flex items-center justify-between pt-2">
                <div className={`text-xs ${t.secondaryText}`}>
                    Powered by Gemini Nano
                </div>
                <button onClick={toggleTheme} className={`p-2 rounded-full ${t.hover} ${t.secondaryText}`}>
                    {theme === 'dark' ? <SunIcon className="w-4 h-4" /> : <MoonIcon className="w-4 h-4" />}
                </button>
           </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col relative">
        {/* Header (Mobile sidebar toggle) */}
        {!isSidebarOpen && (
          <div className="absolute top-4 left-4 z-10">
             <button onClick={() => setIsSidebarOpen(true)} className={`p-2 ${t.sidebar} rounded-full shadow-lg border`}>
              <MenuIcon className="w-5 h-5" />
            </button>
          </div>
        )}

        {viewMode === 'autopilot' ? (
           <AutopilotView brandProfile={brandProfile} />
        ) : (
           <>
                {/* Chat Area */}
                <div className="flex-1 overflow-y-auto p-4 md:p-10 flex flex-col items-center">
                {messages.length === 0 ? (
                    <div className="flex-1 flex flex-col items-center justify-center text-center max-w-2xl">
                    <div className="w-16 h-16 mb-6 bg-gradient-to-tr from-blue-500 to-purple-500 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20">
                        <SparklesIcon className="w-8 h-8 text-white" />
                    </div>
                    <h1 className="text-4xl md:text-5xl font-google font-medium mb-4 gemini-gradient-text bg-clip-text text-transparent">
                        Hello, Creator.
                    </h1>
                    <p className={`text-xl ${t.secondaryText} mb-8`}>
                        {brandProfile 
                            ? `Creating content for ${brandProfile.name}` 
                            : "What social content or apps are we building today?"}
                    </p>
                    {brandProfile && (
                        <div className={`px-4 py-2 rounded-full text-sm ${theme === 'dark' ? 'bg-[#28292A] text-purple-300' : 'bg-purple-50 text-purple-700'} border border-purple-500/30 flex items-center gap-2`}>
                            <div className="w-2 h-2 rounded-full bg-purple-500 animate-pulse" />
                            Brand Profile Active
                        </div>
                    )}
                    </div>
                ) : (
                    <div className="w-full max-w-4xl flex flex-col gap-6 pb-32">
                    {messages.map((msg) => (
                        <div key={msg.id} className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        {msg.role === 'model' && (
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-red-400 flex items-center justify-center mr-4 flex-shrink-0 mt-1">
                            <SparklesIcon className="w-4 h-4 text-white" />
                            </div>
                        )}
                        
                        <div className={`flex flex-col gap-2 max-w-[95%] md:max-w-[85%] ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                            
                            {/* Loading State - Simple */}
                            {msg.isLoading && !msg.buildLog && (
                            <div className={`shimmer w-64 h-20 rounded-2xl ${theme === 'dark' ? 'bg-[#28292A]' : 'bg-[#eef0f2]'}`}></div>
                            )}

                            {/* Social Content Preview (Replaces raw Image/Video) */}
                            {!msg.isLoading && (msg.imageUrl || msg.videoUrl) && (
                                <div className="mb-2 w-full">
                                    <SocialPreview 
                                        platform={msg.metadata?.platform || selectedPlatform}
                                        imageUrl={msg.imageUrl}
                                        videoUrl={msg.videoUrl}
                                        caption={msg.text || ''}
                                        profileName={brandProfile?.name || "Beauto Brand"}
                                        profileImage={brandProfile?.avatarUrl}
                                        onEdit={msg.imageUrl ? () => setEditingImage({ url: msg.imageUrl!, messageId: msg.id }) : undefined}
                                    />
                                </div>
                            )}

                            {/* APP BUILDER CONTENT (Build Log or Files) */}
                            {(msg.projectFiles || (msg.isLoading && msg.buildLog && msg.metadata?.contentType !== ContentType.Seo)) && (
                                <div className="w-full min-w-[300px] md:min-w-[700px]">
                                    <LivePreview 
                                        files={msg.projectFiles} 
                                        buildLog={msg.buildLog} 
                                        isLoading={msg.isLoading}
                                    />
                                </div>
                            )}

                            {/* Text Content (Fallback/Standard) - Handles SEO, Post Captions, etc */}
                            {!msg.isLoading && msg.text && 
                            !msg.imageUrl && !msg.videoUrl && (
                            <div className={`px-5 py-3.5 rounded-2xl text-[15px] leading-relaxed ${
                                msg.role === 'user' 
                                ? `${t.userMsgBg} ${t.userMsgText} rounded-tr-none` 
                                : `${t.modelMsgText} w-full`
                            }`}>
                                
                                {/* Embedded SERP Preview for SEO */}
                                {msg.metadata?.contentType === ContentType.Seo && (
                                    <SerpPreview text={msg.text} />
                                )}

                                <div className="prose dark:prose-invert max-w-none prose-sm prose-p:leading-relaxed prose-pre:bg-[#1a1a1a] prose-pre:border prose-pre:border-[#333]">
                                    <ReactMarkdown 
                                        remarkPlugins={[remarkGfm]}
                                        components={{
                                            table: ({node, ...props}) => (
                                                <div className="overflow-x-auto my-4 rounded-lg border border-gray-200 dark:border-[#444746] bg-black/5 dark:bg-white/5">
                                                    <table className="min-w-full divide-y divide-gray-200 dark:divide-[#444746]" {...props} />
                                                </div>
                                            ),
                                            thead: ({node, ...props}) => (
                                                <thead className="bg-gray-50 dark:bg-[#28292A]" {...props} />
                                            ),
                                            th: ({node, ...props}) => (
                                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider" {...props} />
                                            ),
                                            td: ({node, ...props}) => (
                                                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300 border-t border-gray-200 dark:border-[#333]" {...props} />
                                            )
                                        }}
                                    >
                                        {msg.text}
                                    </ReactMarkdown>
                                </div>
                            </div>
                            )}
                            
                            {/* Metadata badge for user message */}
                            {msg.role === 'user' && msg.metadata && (
                                <span className={`text-[10px] uppercase tracking-wider mr-1 ${t.secondaryText}`}>
                                    {msg.metadata.platform} • {msg.metadata.contentType}
                                </span>
                            )}
                        </div>
                        </div>
                    ))}
                    <div ref={messagesEndRef} />
                    </div>
                )}
                </div>

                {/* Input Area */}
                <div className={`w-full p-4 flex flex-col items-center justify-center ${theme === 'dark' ? 'bg-gradient-to-t from-[#131314] via-[#131314] to-transparent' : 'bg-gradient-to-t from-white via-white to-transparent'} pb-6`}>
                <div className={`w-full max-w-3xl ${t.inputBg} rounded-3xl border ${t.inputBorder} flex flex-col shadow-2xl relative`}>
                    
                    {/* Controls Header */}
                    <div className={`flex items-center justify-between px-4 pt-3 pb-2 border-b ${theme === 'dark' ? 'border-[#333]' : 'border-gray-200'}`}>
                        
                        {/* Platform Selector (Only show for Social Types) */}
                        {(selectedContentType !== ContentType.App && selectedContentType !== ContentType.Seo) ? (
                            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
                                {platforms.map(p => (
                                    <button 
                                        key={p.id}
                                        onClick={() => setSelectedPlatform(p.id)}
                                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
                                            selectedPlatform === p.id 
                                            ? (theme === 'dark' ? 'bg-[#333] border-blue-500/50 text-blue-400' : 'bg-blue-100 border-blue-200 text-blue-700')
                                            : `border-transparent ${t.secondaryText} ${t.hover}`
                                        }`}
                                    >
                                        <p.icon className="w-3.5 h-3.5" />
                                        {p.label}
                                    </button>
                                ))}
                            </div>
                        ) : (
                            <div className="flex items-center gap-2 px-1">
                                <span className={`text-xs font-medium ${t.secondaryText} flex items-center gap-2`}>
                                    {selectedContentType === ContentType.App ? (
                                        <>
                                            <CodeIcon className="w-3.5 h-3.5" />
                                            No-Code App Builder Mode
                                        </>
                                    ) : (
                                        <>
                                            <ChartIcon className="w-3.5 h-3.5" />
                                            SEO Specialist Mode
                                        </>
                                    )}
                                </span>
                            </div>
                        )}

                        {/* Type Selector */}
                        <div className={`flex ${theme === 'dark' ? 'bg-[#131314]' : 'bg-white border border-gray-200'} rounded-full p-1`}>
                            <button 
                                onClick={() => setSelectedContentType(ContentType.Post)}
                                className={`px-3 py-1 rounded-full text-xs transition-all ${
                                    selectedContentType === ContentType.Post 
                                        ? (theme === 'dark' ? 'bg-[#28292A] text-white' : 'bg-gray-100 text-gray-900 font-medium') 
                                        : 'text-gray-500 hover:text-gray-400'
                                }`}
                            >
                                Post
                            </button>
                            <button 
                                onClick={() => setSelectedContentType(ContentType.Reel)}
                                className={`px-3 py-1 rounded-full text-xs transition-all ${
                                    selectedContentType === ContentType.Reel 
                                        ? (theme === 'dark' ? 'bg-[#28292A] text-white' : 'bg-gray-100 text-gray-900 font-medium')
                                        : 'text-gray-500 hover:text-gray-400'
                                }`}
                            >
                                Reel
                            </button>
                            <button 
                                onClick={() => setSelectedContentType(ContentType.App)}
                                className={`px-3 py-1 rounded-full text-xs transition-all flex items-center gap-1 ${
                                    selectedContentType === ContentType.App 
                                        ? (theme === 'dark' ? 'bg-[#28292A] text-blue-400' : 'bg-blue-50 text-blue-700 font-medium')
                                        : 'text-gray-500 hover:text-gray-400'
                                }`}
                            >
                                App
                            </button>
                            <button 
                                onClick={() => setSelectedContentType(ContentType.Seo)}
                                className={`px-3 py-1 rounded-full text-xs transition-all flex items-center gap-1 ${
                                    selectedContentType === ContentType.Seo 
                                        ? (theme === 'dark' ? 'bg-[#28292A] text-green-400' : 'bg-green-50 text-green-700 font-medium')
                                        : 'text-gray-500 hover:text-gray-400'
                                }`}
                            >
                                SEO
                            </button>
                        </div>
                    </div>

                    <textarea
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => {
                            if(e.key === 'Enter' && !e.shiftKey) {
                                e.preventDefault();
                                handleSend();
                            }
                        }}
                        placeholder={
                            selectedContentType === ContentType.App 
                            ? "Describe the app or website (e.g. 'Landing page for my brand')..."
                            : selectedContentType === ContentType.Seo
                            ? "Ask for SEO strategy (e.g. 'Find keywords for vegan shoes')..."
                            : `Create a ${selectedContentType === ContentType.Reel ? 'Veo video' : 'Nano Image'} & caption...`
                        }
                        className={`w-full bg-transparent ${t.text} placeholder-gray-500 px-5 py-4 focus:outline-none resize-none h-auto min-h-[60px] max-h-32 rounded-b-3xl`}
                        rows={1}
                    />
                    
                    <div className="absolute bottom-3 right-3">
                        <button 
                        onClick={handleSend}
                        disabled={!input.trim() || isProcessing}
                        className={`p-2 rounded-full transition-all ${
                            input.trim() && !isProcessing 
                            ? (theme === 'dark' ? 'bg-white text-black hover:bg-gray-200' : 'bg-blue-600 text-white hover:bg-blue-700')
                            : (theme === 'dark' ? 'bg-[#333] text-gray-500' : 'bg-gray-200 text-gray-400') + ' cursor-not-allowed'
                        }`}
                        >
                        {isProcessing ? (
                            <div className={`w-5 h-5 border-2 ${theme === 'dark' ? 'border-gray-500' : 'border-white'} border-t-transparent rounded-full animate-spin`} />
                        ) : (
                            <SendIcon className="w-5 h-5" />
                        )}
                        </button>
                    </div>
                </div>
                <p className={`text-[10px] ${t.secondaryText} mt-3`}>
                    Beauto can make mistakes. Verify generated content.
                </p>
                </div>
           </>
        )}

      </div>
    </div>
  );
};
