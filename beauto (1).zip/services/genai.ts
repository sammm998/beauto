
import { GoogleGenAI, Type } from "@google/genai";
import { BrandProfile, ProjectFile, CalendarPost, Platform, ContentType, SeoAudit, ContentTheme } from "../types";

// Initialize the client. We use a function to get a fresh instance 
// because the API Key might change if the user selects a paid key for Veo.
const getAiClient = (customKey?: string) => {
  const apiKey = customKey || process.env.API_KEY;
  return new GoogleGenAI({ apiKey });
};

/**
 * Analyzes a brand from a URL using Google Search grounding.
 * Now performs a DEEP CRAWL simulation to capture visual environment and site structure.
 */
export const analyzeBrandFromUrl = async (url: string): Promise<BrandProfile> => {
  const ai = getAiClient();
  let domain = '';
  try {
    domain = new URL(url).hostname;
  } catch (e) {
    domain = url;
  }
  
  const systemInstruction = `You are a world-class Brand Strategist and Technical Crawler. 
  Your goal is to build the "Foundation" for a generative AI model specific to this brand.
  
  You must deeply analyze the provided website URL to extract the DNA of the company.
  
  CRITICAL INSTRUCTION FOR DEEP CRAWL & VISUAL MATCHING:
  You must simulate a "Full Site Crawl".
  1. **Structure**: Look for 'sitemap.xml' and 'robots.txt' patterns to understand site hierarchy.
  2. **Visual Environment**: You must find multiple images on the site to understand the *physical environment* of the brand.
     - Is it a dark, moody office? A bright outdoor setting? A clean medical facility?
     - What defines the "Backgrounds" of their photos? (e.g. "Blurry city lights", "White studio backdrop", "Forest").
     - Extract this as 'visualEnvironment'.
  
  CRITICAL INSTRUCTION FOR VISUAL ACCURACY:
  You must identify the "Key Physical Elements" of the brand.
  - If it is a Taxi company, what color are the cars? (e.g. "Yellow Mercedes Taxis", "Black Sedans").
  - If it is a Food brand, what is the packaging?
  - Look for "Signature Objects".
  
  CRITICAL INSTRUCTION FOR TARGET AUDIENCE:
  You MUST deduce a specific Target Audience based on the site content. 
  - If they sell expensive items -> High Income.
  - If they use slang/trendy visuals -> Gen Z/Millennials.
  - If they mention "tax", "accounting", "efficiency" -> Business Owners/B2B.
  
  CRITICAL INSTRUCTION FOR LOGO EXTRACTION:
  You must act as a browser looking for the *actual image file* of the brand's logo.
  1.  **Prioritize Vector/High-Res**: Look for .svg, .png, or .webp files.
  2.  **Common Locations**: 
      - WordPress: /wp-content/uploads/YYYY/MM/logo.png
      - Shopify: cdn.shopify.com/.../logo.png
      - General: /images/logo.png, /assets/img/logo.svg
  3.  **Search Strategy**: Use the search tool to find the specific image URL. 
      - Query: "site:${domain} logo filetype:png"
      - Query: "site:${domain} logo filetype:svg"
      - Query: "${domain} logo url"
      - Query: "site:${domain} wp-content logo"
  4.  **Validation**: The URL MUST end in an image extension (.png, .jpg, .svg, .webp) or look like a CDN image link. 
      - DO NOT return the website URL itself.
      - DO NOT return a tiny favicon.ico unless absolutely nothing else exists.
      - DO NOT return "placeholder" images.

  CRITICAL INSTRUCTION FOR LANGUAGE:
  Detect the primary language used on the website (e.g., "Swedish", "English", "German").
  Return this language so all future content is generated in that language.

  CRITICAL OUTPUT INSTRUCTION:
  You must return ONLY a valid JSON object. Do not include any conversational text.
  The JSON must match this structure:
  {
    "name": "Brand Name",
    "description": "Short description",
    "industry": "Specific Industry or Niche (e.g. 'High-End Real Estate', 'Sustainable Fashion')",
    "knowledgeBase": "A comprehensive, multi-paragraph manifesto of the brand. Include: Core Services/Products, Unique Value Propositions, Mission Statement, and Key Terminology they use.",
    "colors": ["#hex1", "#hex2", "#hex3"],
    "visualStyle": "General aesthetic (e.g. 'Minimalist')",
    "visualEnvironment": "Detailed description of the physical setting seen in brand photos (e.g. 'Modern office with glass walls', 'Sunny outdoor park')",
    "keyElements": ["List of physical objects/colors", "e.g. Yellow Taxis", "Blue Uniforms"],
    "voice": "Detailed voice description",
    "language": "The primary language of the website (e.g. 'Swedish')",
    "logoUrl": "The exact absolute URL of the brand's logo image found on the site.",
    "targetAudience": {
        "ageGroup": "Specific range",
        "geo": "Primary market",
        "interests": ["Interest 1", "Interest 2"],
        "painPoints": ["Pain Point 1", "Pain Point 2"]
    },
    "referenceImageUrls": ["url1", "url2"]
  }`;

  const prompt = `Perform a DEEP CRAWL ANALYSIS of the website: ${url}. 
  
  TASKS:
  1. **Site Structure**: Infer structure from navigation and common patterns (sitemap, robots).
  2. **Image Crawl**: Search for images hosted on ${domain} to understand the visual consistency.
     - Query: "site:${domain} filetype:jpg"
     - Query: "site:${domain} filetype:png"
     - Analyze these images to populate 'visualEnvironment'.
  3. **Extract Brand DNA**: Name, Industry, Knowledge Base.
  4. **Target Audience**: Deduce who the content is for.
  5. **Language**: Detect primary language.
  6. **Key Elements**: What physical objects appear repeatedly? (e.g. Specific car models, uniforms).
  
  7. **FIND THE LOGO (HIGHEST PRIORITY)**:
     - I need the DIRECT LINK to the logo image file.
     - **Check patterns**:
       - ${url}/wp-content/uploads/ (Search for logo files here)
       - ${url}/assets/images/
     - **Execute Search**:
       - "site:${domain} logo filetype:png"
       - "site:${domain} logo filetype:svg"
       - "${domain} header logo url"
     - **Return**: The absolute URL (e.g., "https://example.com/wp-content/uploads/2023/logo.png").

  Return ONLY valid JSON.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        tools: [{ googleSearch: {} }],
      },
    });

    let text = response.text || "{}";
    
    // Remove markdown code blocks if present (e.g. ```json ... ```)
    text = text.replace(/```json\n?|```/g, '').trim();

    const result = JSON.parse(text);
    
    let logoUrl = result.logoUrl;

    // Fallback: If no logo was found by the AI or it looks invalid, use Google's Favicon service
    // We check for "placeholder", "example.com", or empty strings to trigger fallback
    if (!logoUrl || logoUrl.trim() === "" || logoUrl.includes("placeholder") || logoUrl.includes("example.com")) {
        try {
            // sz=512 requests a high-res icon (max size)
            logoUrl = `https://www.google.com/s2/favicons?domain=${domain}&sz=512`;
        } catch (e) {
            // If URL parsing fails, ignore
        }
    }
    
    return {
      url,
      name: result.name || "Unknown Brand",
      description: result.description || "No description found.",
      industry: result.industry || "General Business",
      knowledgeBase: result.knowledgeBase || "No detailed information available.",
      colors: result.colors || ["#000000"],
      visualStyle: result.visualStyle || "Clean and professional",
      visualEnvironment: result.visualEnvironment || "Neutral background",
      keyElements: result.keyElements || [],
      voice: result.voice || "Professional and helpful",
      language: result.language || "English",
      logoUrl: logoUrl,
      targetAudience: {
          ageGroup: result.targetAudience?.ageGroup || "General Audience",
          geo: result.targetAudience?.geo || "Global",
          interests: result.targetAudience?.interests?.length > 0 ? result.targetAudience.interests : ["General Interest"],
          painPoints: result.targetAudience?.painPoints?.length > 0 ? result.targetAudience.painPoints : ["Unspecified needs"]
      },
      products: [],
      referenceImageUrls: result.referenceImageUrls || []
    };

  } catch (error) {
    console.error("Brand Analysis Error:", error);
    throw new Error("Could not analyze the provided URL. Please try again.");
  }
};

/**
 * Extracts specific products from the brand's website.
 */
export const extractBrandProducts = async (brand: BrandProfile): Promise<BrandProfile> => {
    const ai = getAiClient();
    const systemInstruction = `You are a Product Data Specialist.
    Find specific products or services offered by ${brand.name} (${brand.url}).
    Return a JSON array of products.`;

    const prompt = `Analyze the website ${brand.url} and find 3-5 key products or services.
    Return JSON format:
    {
        "products": [
            { "name": "Product Name", "description": "Short description", "imageUrl": "URL to product image" }
        ]
    }
    Use googleSearch to find actual product images if possible.`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                tools: [{ googleSearch: {} }],
                responseMimeType: 'application/json'
            }
        });

        const text = response.text || "{}";
        const result = JSON.parse(text);
        
        return {
            ...brand,
            products: result.products || []
        };

    } catch (e) {
        console.error("Product Extraction Error", e);
        return brand;
    }
};

/**
 * Dedicated SEO Crawl Function.
 * Performs a separate deep dive for SEO metrics.
 */
export const runSeoAudit = async (url: string): Promise<string> => {
    const ai = getAiClient();
    
    const prompt = `Perform a comprehensive Technical SEO Audit for: ${url}.
    
    TASKS:
    1. Analyze the Homepage Title Tag and Meta Description. Are they optimized? Length?
    2. Identify the top 5 ranking keywords based on content analysis.
    3. Check for structural issues (H1, H2 tags).
    4. Provide 3 high-impact recommendations to improve ranking.
    
    OUTPUT FORMAT:
    Return a structured Markdown report. Use tables for keywords. Use icons for status (✅, ⚠️, ❌).`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }],
            },
        });
        
        return response.text || "Could not generate SEO Audit.";
    } catch (e) {
        console.error("SEO Audit Error", e);
        return "Failed to perform SEO Audit.";
    }
}

/**
 * Generates a Realistic Brand Avatar using the brand profile.
 * Upgraded to gemini-3-pro-image-preview for realism.
 */
export const generateBrandAvatar = async (profile: BrandProfile): Promise<string | null> => {
  const ai = getAiClient();
  try {
    const prompt = `Create a photorealistic portrait of a professional human brand ambassador for "${profile.name}".
    
    BRAND FOUNDATION:
    - Industry: ${profile.industry}
    - Brand Colors: ${profile.colors.join(', ')}
    - Visual Style: ${profile.visualStyle}
    - Visual Environment: ${profile.visualEnvironment}
    - Key Elements: ${profile.keyElements?.join(', ')}
    
    IMAGE REQUIREMENTS:
    - Subject: A real human person (not a cartoon, not a 3D render). 
    - Appearance: Professional, trustworthy, approachable, and dressed in attire suitable for a ${profile.industry} professional.
    - Setting: ${profile.visualEnvironment || `A high-quality, blurred background that hints at a modern office or ${profile.industry} environment.`}
    - Lighting: Studio quality, soft, natural lighting.
    - Quality: 8k resolution, highly detailed skin texture, realistic eyes, photography style.
    - Composition: Head and shoulders portrait, looking directly at the camera with a warm smile.
    - Color Grading: Subtly incorporate the brand colors ${profile.colors.join(', ')} in the clothing or background accent.
    - CONSTRAINT: NO TEXT. Do not include any text, logos, or writing in the image.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [
          { text: prompt }
        ]
      },
      config: {
        imageConfig: {
            aspectRatio: "1:1",
            imageSize: "2K"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Avatar Generation Error:", error);
    return null;
  }
};

/**
 * Generates text content (captions, hashtags) using Gemini 2.5 Flash.
 */
export const generateSocialCaption = async (
  platform: string,
  contentType: string,
  prompt: string,
  brand?: BrandProfile
): Promise<string> => {
  const ai = getAiClient();
  
  let systemInstruction = `You are the Lead Social Media Manager and Brand Voice Architect for ${brand ? brand.name : 'a premium brand'}.
  Your content must be indistinguishable from a human marketing expert working internally at the company.`;

  if (brand) {
    systemInstruction += `
    
    BRAND FOUNDATION (IMMUTABLE):
    ---------------------------------------------------
    NAME: ${brand.name}
    INDUSTRY: ${brand.industry}
    VOICE & TONE: ${brand.voice} (Strictly adhere to this.)
    LANGUAGE: ${brand.language} (ALL OUTPUT MUST BE IN THIS LANGUAGE)
    
    TARGET AUDIENCE:
    - Age: ${brand.targetAudience?.ageGroup}
    - Interests: ${brand.targetAudience?.interests?.join(', ')}
    - Pain Points: ${brand.targetAudience?.painPoints?.join(', ')}
    
    KNOWLEDGE BASE (SOURCE OF TRUTH):
    ${brand.knowledgeBase}
    
    VISUAL STYLE:
    ${brand.visualStyle}
    ---------------------------------------------------

    INSTRUCTIONS:
    1. Generate an engaging ${platform} ${contentType} caption for the concept: "${prompt}".
    2. DEEPLY INTEGRATE the Knowledge Base: Reference specific services, products, or values.
    3. Match the Tone of Voice exactly.
    4. Speak directly to the Target Audience identified above.
    5. Include strategic, niche hashtags.
    6. **LANGUAGE REQUIREMENT**: The caption MUST be written in ${brand.language}. If the brand is Swedish, write in Swedish.
    `;
  } else {
    systemInstruction += `\nGenerate an engaging ${platform} ${contentType} caption for: "${prompt}". Include relevant emojis and hashtags.`;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
      },
    });
    return response.text || "Could not generate caption.";
  } catch (error) {
    console.error("Text Generation Error:", error);
    return "Error generating caption. Please try again.";
  }
};

/**
 * Generates an image using Gemini 3 Pro Image Preview (Nano Banana Pro).
 * Supports creating new images OR editing existing product images if provided.
 */
export const generateImage = async (prompt: string, brand?: BrandProfile, sourceImageUrl?: string): Promise<string | null> => {
  const ai = getAiClient();
  try {
    let enhancedPrompt = `High quality, professional photography, 8k resolution. Subject: ${prompt}.`;

    if (brand) {
      enhancedPrompt += `
      
      STRICT BRAND VISUAL GUIDELINES:
      - Brand Name: ${brand.name}
      - Industry Context: ${brand.industry}
      - Core Services/Products: ${brand.knowledgeBase} (Ensure the image relates to this)
      - Visual Style: ${brand.visualStyle} (Apply this aesthetic strictly)
      - **VISUAL ENVIRONMENT (CRITICAL)**: ${brand.visualEnvironment} (The image must look like it was taken in this specific setting).
      - **KEY PHYSICAL ELEMENTS**: ${brand.keyElements?.join(', ')} (e.g. if 'Yellow Taxis', ensure cars are Yellow).
      - BRAND COLORS: ${brand.colors.join(', ')}. Use these for the main subjects.
      
      INSTRUCTION:
      Create an image that looks like it belongs on the official Instagram feed of ${brand.name}. 
      It should be highly aesthetic, on-brand, and professional. 
      If the brand uses specific vehicle colors (like Yellow Taxis), YOU MUST USE THAT COLOR.
      
      NEGATIVE CONSTRAINTS (CRITICAL):
      - DO NOT render any text, words, captions, logos, or watermarks inside the image pixels.
      - DO NOT produce distorted vehicles, missing wheels, or malformed objects.
      - Ensure photo-realism and correct anatomy/physics.
      - The image should be clean photography or art only.
      `;
    } else {
      enhancedPrompt += `\nNEGATIVE CONSTRAINTS: Do not render text or words inside the image.`;
    }

    let contents: any = {
        parts: [{ text: enhancedPrompt }]
    };

    // If a source image is provided (e.g. from Product extraction), use it for Image-to-Image
    if (sourceImageUrl) {
        try {
            const resp = await fetch(sourceImageUrl);
            const blob = await resp.blob();
            const base64 = await new Promise<string>((resolve) => {
                const reader = new FileReader();
                reader.onloadend = () => resolve(reader.result as string);
                reader.readAsDataURL(blob);
            });
            const cleanBase64 = base64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, '');
            
            contents = {
                parts: [
                    {
                        inlineData: {
                            mimeType: 'image/png', // Simplification, ideally detect from blob
                            data: cleanBase64
                        }
                    },
                    { text: enhancedPrompt + " Transform this product image to match the requested style." }
                ]
            };
        } catch (e) {
            console.warn("Could not load source image for editing, falling back to text-to-image.", e);
        }
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: contents,
      config: {
        imageConfig: {
            aspectRatio: "1:1",
            imageSize: "2K"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Image Generation Error:", error);
    throw error;
  }
};

/**
 * Edits an image using Gemini 3 Pro Image Preview.
 * Takes base64 image and text prompt to generate a new version.
 */
export const editImage = async (imageBase64: string, editPrompt: string): Promise<string | null> => {
    const ai = getAiClient();
    try {
        // Strip prefix if present for the API call
        const cleanBase64 = imageBase64.replace(/^data:image\/(png|jpeg|jpg);base64,/, '');

        const response = await ai.models.generateContent({
            model: 'gemini-3-pro-image-preview',
            contents: {
                parts: [
                    {
                        inlineData: {
                            mimeType: 'image/png',
                            data: cleanBase64
                        }
                    },
                    { text: editPrompt }
                ]
            },
            config: {
                imageConfig: {
                    aspectRatio: "1:1",
                    imageSize: "2K"
                }
            }
        });

        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) {
                return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
            }
        }
        return null;

    } catch (error) {
        console.error("Image Editing Error:", error);
        throw error;
    }
}

/**
 * Generates a video using Veo 3.1.
 * Uses 'veo-3.1-generate-preview' for high quality as requested.
 * Supports Image-to-Video if sourceImageUrl is provided.
 */
export const generateVideo = async (prompt: string, brand?: BrandProfile, sourceImageUrl?: string): Promise<string | null> => {
  const ai = getAiClient(); 

  let videoPrompt = `Cinematic, high quality 4k social media video: ${prompt}`;
  if (brand) {
    videoPrompt += `
    
    BRAND STYLE & COLORS:
    - Industry: ${brand.industry}
    - Aesthetic: ${brand.visualStyle}
    - **VISUAL ENVIRONMENT (MANDATORY)**: ${brand.visualEnvironment || "Professional Setting"}
       (The video must take place in this specific environment found on their website).
    - KEY PHYSICAL OBJECTS: ${brand.keyElements?.join(', ')} (MANDATORY).
    - If the Key Elements specify a color (e.g. Yellow Taxi), THE VIDEO MUST SHOW THAT COLOR.
    - Brand Colors: ${brand.colors.join(', ')}.
    - Subject Context: Relevant to ${brand.knowledgeBase}
    `;
  }

  let imageInput = undefined;

  // Handle Image-to-Video
  if (sourceImageUrl) {
      try {
        const resp = await fetch(sourceImageUrl);
        const blob = await resp.blob();
        const base64 = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.readAsDataURL(blob);
        });
        const cleanBase64 = base64.replace(/^data:image\/(png|jpeg|jpg|webp);base64,/, '');
        
        imageInput = {
            imageBytes: cleanBase64,
            mimeType: 'image/png' // Assuming png/jpeg compatible
        };
      } catch (e) {
          console.warn("Failed to load source image for video, falling back to text-to-video.");
      }
  }

  try {
    let operation = await ai.models.generateVideos({
      model: 'veo-3.1-generate-preview',
      prompt: videoPrompt,
      image: imageInput,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio: '9:16'
      }
    });

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    const videoUri = operation.response?.generatedVideos?.[0]?.video?.uri;
    
    if (videoUri) {
        const key = process.env.API_KEY;
        const response = await fetch(`${videoUri}&key=${key}`);
        if (!response.ok) {
            throw new Error(`Video fetch failed: ${response.status} ${response.statusText}`);
        }
        const blob = await response.blob();
        return URL.createObjectURL(blob);
    }
    return null;

  } catch (error) {
    console.error("Video Generation Error:", error);
    throw error;
  }
};

/**
 * Generates a functional web app (HTML/CSS/JS) as multiple files.
 * Supports iterative updates (editing existing code) AND Image Generation.
 */
export const generateAppCode = async (
    prompt: string, 
    brand?: BrandProfile, 
    previousCode?: ProjectFile[]
): Promise<{ files: ProjectFile[], imageRequests?: { id: string, prompt: string }[] }> => {
    const ai = getAiClient();
    
    let brandContext = "";
    if (brand) {
        brandContext = `
        BRAND IDENTITY (MANDATORY IMPLEMENTATION):
        - Name: ${brand.name}
        - Industry: ${brand.industry}
        - Detailed Offerings/Copy: ${brand.knowledgeBase} (Use this text for the content of the website)
        - Primary Colors: ${brand.colors.join(', ')} (Use strictly in CSS)
        - Logo URL: ${brand.logoUrl || 'https://via.placeholder.com/150'}
        - Visual Style: ${brand.visualStyle}
        - Visual Environment: ${brand.visualEnvironment} (Use for background image prompts)
        - Language: ${brand.language} (ALL TEXT MUST BE IN THIS LANGUAGE)
        
        INSTRUCTIONS:
        - Write all headers, paragraphs, and buttons in ${brand.language}.
        - Apply the brand colors to buttons, headers, and accents via Tailwind (e.g., bg-[${brand.colors[0] || '#000'}], text-[${brand.colors[1] || '#333'}]).
        - Use the specific services/products from the Knowledge Base in the HTML content sections.
        - Ensure the design style matches the Visual Style.
        `;
    }

    let historyContext = "";
    if (previousCode && previousCode.length > 0) {
        historyContext = `
        CONTEXT - PREVIOUS VERSION:
        The user wants to EDIT the existing application. 
        Here is the current code state:
        ${JSON.stringify(previousCode)}

        TASK:
        - Modify the existing code to satisfy the user's NEW request ("${prompt}").
        - Keep the rest of the app functional.
        - Return the FULLY UPDATED code for all files (do not return diffs).
        `;
    }

    const systemInstruction = `You are an Award-Winning Creative Frontend Architect and UI Designer.
    Your task is to build a **High-End, Modern, and Professional** web application or landing page.

    DESIGN STANDARDS (MODERN & PROFESSIONAL):
    1. **Layouts**: Use modern patterns like "Bento Grids", "Sticky Headers", "Split Hero Sections", and "Masonry Galleries".
    2. **Glassmorphism**: Use backdrop-blur effects (e.g., \`backdrop-blur-md bg-white/10\`) for cards and navigation to create depth.
    3. **Typography**: 
       - Import Google Fonts via <link> in HTML. 
       - Use 'Inter' or 'Space Grotesk' for Modern/Tech brands.
       - Use 'Playfair Display' or 'Cinzel' for Luxury/Classic brands.
       - Use 'Poppins' for playful/creative brands.
    4. **Icons**: **IMPORTANT**: Do not use emojis. Use **Lucide Icons** via CDN.
       - Add this script to HTML head: <script src="https://unpkg.com/lucide@latest"></script>
       - Render icons using the <i> tag: <i data-lucide="camera" class="w-6 h-6"></i>
       - Call \`lucide.createIcons();\` at the end of the body in index.html (or in script.js).
    5. **Animations**: Add subtle CSS animations.
       - Fade-ins on scroll.
       - Hover effects on buttons (transform: scale, shadow-lg).
       - Smooth scrolling (<html class="scroll-smooth">).
    6. **Color Palette**: Use the brand colors provided using Tailwind's arbitrary value syntax (e.g. \`text-[#FF5733]\`). Do not use generic colors unless necessary.
    
    OUTPUT FORMAT:
    You must return a valid JSON object containing an array of files AND an optional array of images to generate.
    Do not return markdown. Return ONLY JSON.
    
    Structure:
    {
      "files": [
        { "name": "index.html", "language": "html", "content": "..." },
        { "name": "styles.css", "language": "css", "content": "..." },
        { "name": "script.js", "language": "javascript", "content": "..." }
      ],
      "imageRequests": [
         { "id": "__IMG_HERO__", "prompt": "A modern office space with glass walls, high tech..." },
         { "id": "__IMG_FEATURE_1__", "prompt": "Close up of a premium watch on a wrist..." }
      ]
    }
    
    IMAGE GENERATION LOGIC:
    - If the design needs specific images (like a Hero background, or Feature cards), DO NOT use via.placeholder.com.
    - Instead, define a unique placeholder ID (e.g. "__IMG_HERO__") and use it in the HTML/CSS (e.g. <img src="__IMG_HERO__" /> or background-image: url('__IMG_HERO__')).
    - Add an entry to 'imageRequests' describing the image visually so an AI can generate it.
    - Limit to max 3 key images to keep generation fast.
    
    REQUIREMENTS:
    1. **Single Page Application (SPA) Structure**: 
       - DO NOT use multi-page navigation (e.g., <a href="about.html">) because relative file linking does not work in this preview environment. 
       - All content must exist in 'index.html'. 
       - Use ID-based internal links (href="#services") or JavaScript to show/hide sections (Tabs/Modal view) for navigation.
    2. Use Tailwind CSS via CDN in index.html: <script src="https://cdn.tailwindcss.com"></script>.
    3. Ensure 'index.html' links to 'styles.css' and 'script.js' correctly.
    
    ${brandContext}
    
    ${historyContext}`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
                responseMimeType: 'application/json'
            },
        });

        let code = response.text || "{}";
        const result = JSON.parse(code);
        
        const files = (result.files && Array.isArray(result.files)) ? result.files : [{
            name: 'error.txt',
            language: 'json',
            content: 'Error: Invalid file structure generated.'
        }];
        
        const imageRequests = (result.imageRequests && Array.isArray(result.imageRequests)) ? result.imageRequests : [];

        return { files, imageRequests };

    } catch (error) {
        console.error("App Generation Error:", error);
        return { 
            files: [{
                name: 'error.html',
                language: 'html',
                content: `<html><body><h1>Error generating app</h1><p>${error}</p></body></html>`
            }]
        };
    }
}

/**
 * Performs a detailed SEO Analysis and Strategy recommendation.
 */
export const generateSeoAnalysis = async (prompt: string, brand?: BrandProfile): Promise<string> => {
    const ai = getAiClient();
    
    let brandContext = "";
    if (brand) {
      brandContext = `
      BRAND CONTEXT (Use for Strategy):
      - Name: ${brand.name}
      - Industry: ${brand.industry}
      - Core Services/Products: ${brand.knowledgeBase}
      - Target Audience: ${brand.targetAudience?.ageGroup} | ${brand.targetAudience?.geo}
      - Language: ${brand.language}
      - Website: ${brand.url}
      
      Your advice MUST be tailored to this specific business and industry.
      `;
    }
  
    const systemInstruction = `You are a Senior SEO Consultant and Content Strategist.
    Your task is to assist the user with specific SEO requests for their brand.
    
    INSTRUCTIONS:
    1. Answer ONLY what the user asks for. Do NOT provide a generic full audit unless explicitly requested.
    2. If the user asks for keywords, provide a structured table (Keyword | Vol | Difficulty) RELEVANT to the Brand's Industry.
    3. If the user asks for blog ideas, use the Brand's Knowledge Base to suggest topics that convert.
    4. If the user asks for technical advice, explain the solution clearly.
    5. Use 'googleSearch' tool to find REAL-TIME data, trends, and rankings.
    6. Format the output in clean, beautiful Markdown.
    
    If the user asks to "audit the site" or "crawl the site" or "analyze the seo", use the 'runSeoAudit' capability logic (or simulate it here by searching the site structure).
    
    ${brandContext}
    
    Be helpful, direct, and data-driven.`;
  
    try {
      // Use Flash for faster responses as requested
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash', 
        contents: prompt,
        config: {
          systemInstruction: systemInstruction,
          tools: [{ googleSearch: {} }],
        },
      });
  
      let text = response.text || "Could not generate SEO analysis.";
      
      // Append grounding sources if available
      if (response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
        text += "\n\n**Sources Analyzed:**\n";
        response.candidates[0].groundingMetadata.groundingChunks.forEach((chunk: any) => {
           if (chunk.web?.uri) {
               text += `- [${chunk.web.title || 'Source'}](${chunk.web.uri})\n`;
           }
        });
      }
      
      return text;
  
    } catch (error) {
      console.error("SEO Generation Error:", error);
      return "Error generating SEO analysis. Please try again.";
    }
  };

/**
 * Generates a full content calendar based on autopilot settings.
 * Returns planned posts with dates, titles, captions, and visual prompts.
 * Automatically initiates generation for the first week.
 */
export const generateContentCalendar = async (
  brand: BrandProfile,
  days: number = 30,
  postsPerWeek: number,
  videoRatio: number, // 0 to 1
  theme: ContentTheme = "Standard" as ContentTheme
): Promise<CalendarPost[]> => {
  const ai = getAiClient();
  
  let themeInstruction = "";
  if (theme === 'Product' && brand.products && brand.products.length > 0) {
      themeInstruction = `STRATEGY THEME: PRODUCT SHOWCASE
      Focus strictly on highlighting the following products found in the brand's portfolio: 
      ${brand.products.map(p => `- ${p.name}: ${p.description}`).join('\n')}
      
      IMPORTANT: For 'visualPrompt', try to describe a scene that matches one of these products perfectly.
      `;
  } else {
      themeInstruction = `STRATEGY THEME SELECTED: "${theme}"
      The user has explicitly selected this theme. All content ideas MUST align with this style.
      - If Cinematic: Focus on high-quality visuals, storytelling, and dramatic composition.
      - If Fun/Viral: Focus on trends, humor, relatable situations, and quick cuts.
      - If Educational: Focus on tips, how-tos, industry secrets, and value.
      `;
  }

  const systemInstruction = `You are the Head of Content Strategy for ${brand.name}.
  Your job is to plan a comprehensive social media calendar for the next ${days} days.
  
  ${themeInstruction}
  
  BRAND DNA:
  - Industry: ${brand.industry}
  - Voice: ${brand.voice}
  - Knowledge Base: ${brand.knowledgeBase}
  - Target Audience: ${brand.targetAudience?.ageGroup} years old, Interested in ${brand.targetAudience?.interests?.join(', ')}. Pain points: ${brand.targetAudience?.painPoints?.join(', ')}.
  - Language: ${brand.language} (MANDATORY)
  
  PARAMETERS:
  - Posts per week: ${postsPerWeek}
  - Video content percentage: ${videoRatio * 100}%
  - Start Date: Today (${new Date().toISOString().split('T')[0]})
  
  OUTPUT INSTRUCTION:
  Return a valid JSON array of 'CalendarPost' objects.
  Structure:
  [
    {
      "id": "1",
      "date": "YYYY-MM-DD",
      "platform": "Instagram", // or TikTok, LinkedIn etc.
      "contentType": "Post", // or Reel
      "title": "Short internal title",
      "caption": "The full social media caption with hashtags... WRITTEN IN ${brand.language}",
      "visualPrompt": "Detailed prompt for the AI image/video generator..."
    }
  ]
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Create a ${days}-day content calendar for ${brand.name} in ${brand.language}.`,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: 'application/json'
      },
    });

    const text = response.text || "[]";
    const posts: CalendarPost[] = JSON.parse(text);
    
    // Normalize status
    return posts.map(p => ({ ...p, status: 'planned' }));

  } catch (error) {
    console.error("Calendar Generation Error:", error);
    return [];
  }
};
