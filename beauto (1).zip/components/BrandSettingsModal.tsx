
import React, { useState, useEffect } from 'react';
import { BrandProfile } from '../types';
import { analyzeBrandFromUrl, generateBrandAvatar } from '../services/genai';
import { GlobeIcon, SparklesIcon, CheckCircle, AlertCircle, SettingsIcon, ImageIcon } from './Icons';

interface BrandSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (profile: BrandProfile) => void;
  currentProfile?: BrandProfile;
}

export const BrandSettingsModal: React.FC<BrandSettingsModalProps> = ({ isOpen, onClose, onSave, currentProfile }) => {
  const [url, setUrl] = useState(currentProfile?.url || '');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStage, setLoadingStage] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [analyzedProfile, setAnalyzedProfile] = useState<BrandProfile | undefined>(currentProfile);
  
  // Local state for editing fields
  const [logoInput, setLogoInput] = useState('');

  useEffect(() => {
    if (currentProfile) {
        setAnalyzedProfile(currentProfile);
        setLogoInput(currentProfile.logoUrl || '');
        setUrl(currentProfile.url);
    }
  }, [currentProfile, isOpen]);

  // Update profile when logo input changes manually
  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setLogoInput(e.target.value);
      if (analyzedProfile) {
          setAnalyzedProfile({ ...analyzedProfile, logoUrl: e.target.value });
      }
  };

  if (!isOpen) return null;

  const handleAnalyze = async () => {
    if (!url.trim()) {
      setError("Please enter a valid URL.");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Stage 1: Text Analysis
      setLoadingStage('Crawling site structure & deep analyzing knowledge base...');
      const profile = await analyzeBrandFromUrl(url);
      
      // Stage 2: Avatar Generation
      setLoadingStage('Generating realistic human brand representative...');
      const avatarUrl = await generateBrandAvatar(profile);
      
      const completeProfile: BrandProfile = {
        ...profile,
        avatarUrl: avatarUrl || undefined
      };

      setAnalyzedProfile(completeProfile);
      setLogoInput(completeProfile.logoUrl || '');
    } catch (e) {
      setError("Failed to analyze brand. Ensure the URL is accessible or try again.");
    } finally {
      setIsLoading(false);
      setLoadingStage('');
    }
  };

  const handleConfirm = () => {
    if (analyzedProfile) {
      onSave(analyzedProfile);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-[#1E1F20] rounded-2xl border border-[#444746] shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto flex flex-col">
        
        {/* Header */}
        <div className="p-6 border-b border-[#444746] flex items-center justify-between bg-[#1E1F20] sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <SettingsIcon className="text-purple-400 w-5 h-5" />
            </div>
            <h2 className="text-xl font-google font-medium text-white">Brand Book & Analysis</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            ✕
          </button>
        </div>

        <div className="p-6 space-y-6">
          
          {/* Input Section */}
          <div className="space-y-3">
            <label className="text-sm text-gray-300 font-medium">Company Website URL</label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <GlobeIcon className="text-gray-500 w-4 h-4" />
                </div>
                <input 
                  type="url" 
                  value={url} 
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://www.example.com"
                  className="w-full bg-[#131314] border border-[#444746] text-white rounded-lg pl-10 pr-4 py-2.5 focus:outline-none focus:border-purple-500 transition-colors"
                />
              </div>
              <button 
                onClick={handleAnalyze}
                disabled={isLoading}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg font-medium transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed min-w-[120px] justify-center"
              >
                {isLoading ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <SparklesIcon className="w-4 h-4" />
                )}
                {isLoading ? 'Working...' : 'Deep Analysis'}
              </button>
            </div>
            <div className="flex justify-between items-start">
                <p className="text-xs text-gray-500">
                AI will crawl site structure to extract brand DNA, visual style, and knowledge base.
                </p>
                {isLoading && (
                    <span className="text-xs text-purple-400 animate-pulse font-medium">
                        {loadingStage}
                    </span>
                )}
            </div>
            
            {error && (
              <div className="flex items-center gap-2 text-red-400 text-sm bg-red-500/10 p-3 rounded-lg border border-red-500/20">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            )}
          </div>

          {/* Results Section: Brand Book */}
          {analyzedProfile && (
            <div className="bg-[#28292A] rounded-xl p-6 border border-[#444746] animate-in fade-in slide-in-from-bottom-4 duration-500">
              
              {/* Brand Header & Logo Section */}
              <div className="flex items-start justify-between mb-6 border-b border-[#444746] pb-6 gap-6">
                  <div className="flex-1">
                    <h3 className="text-white font-medium flex items-center gap-2 text-lg mb-1">
                      <CheckCircle className="w-5 h-5 text-green-400" />
                      {analyzedProfile.name}
                    </h3>
                    <span className="text-xs text-gray-400 ml-7 block mb-4">{analyzedProfile.industry}</span>
                    
                    {/* Dedicated Logo Field */}
                    <div className="ml-7 bg-[#131314] p-3 rounded-lg border border-[#444746]">
                        <label className="text-[10px] uppercase tracking-wider text-gray-500 block mb-2">Detected Brand Logo</label>
                        <div className="flex gap-3 items-center">
                            <div className="w-12 h-12 bg-white/5 rounded-md border border-white/10 flex items-center justify-center overflow-hidden shrink-0">
                                {logoInput ? (
                                    <img src={logoInput} alt="Brand Logo" className="w-full h-full object-contain" onError={(e) => (e.currentTarget.style.display = 'none')} />
                                ) : (
                                    <ImageIcon className="w-6 h-6 text-gray-600" />
                                )}
                            </div>
                            <div className="flex-1">
                                <input 
                                    type="text" 
                                    value={logoInput}
                                    onChange={handleLogoChange}
                                    placeholder="Paste Logo URL here if detection failed..."
                                    className="w-full bg-[#1E1F20] text-xs text-gray-300 border border-[#444746] rounded px-2 py-1.5 focus:outline-none focus:border-purple-500"
                                />
                            </div>
                        </div>
                    </div>
                  </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Left Column: Text Details */}
                  <div className="space-y-5">
                    
                    <div>
                    <span className="text-[10px] uppercase tracking-wider text-gray-500 block mb-1">Deep Knowledge Base</span>
                    <div className="text-sm text-gray-300 bg-[#131314] p-3 rounded-lg border border-[#444746] max-h-40 overflow-y-auto custom-scrollbar leading-relaxed">
                        {analyzedProfile.knowledgeBase}
                    </div>
                    </div>

                    <div>
                    <span className="text-[10px] uppercase tracking-wider text-gray-500 block mb-1">Voice & Tone</span>
                    <div className="text-sm text-blue-200 bg-blue-500/10 px-3 py-2 rounded-lg border border-blue-500/20 inline-block">
                        {analyzedProfile.voice}
                    </div>
                    </div>

                    {/* Target Audience Section (New) */}
                    <div>
                        <span className="text-[10px] uppercase tracking-wider text-gray-500 block mb-1">Target Audience</span>
                        <div className="bg-[#131314] p-3 rounded-lg border border-[#444746] space-y-3">
                            <div className="flex gap-4 border-b border-[#28292A] pb-2">
                                <div>
                                    <span className="text-[10px] text-gray-500 block">Age</span>
                                    <span className="text-xs text-gray-300">{analyzedProfile.targetAudience?.ageGroup || 'N/A'}</span>
                                </div>
                                <div>
                                    <span className="text-[10px] text-gray-500 block">Location</span>
                                    <span className="text-xs text-gray-300">{analyzedProfile.targetAudience?.geo || 'Global'}</span>
                                </div>
                            </div>
                            
                            <div>
                                <span className="text-[10px] text-gray-500 block mb-1">Interests</span>
                                <div className="flex flex-wrap gap-1">
                                    {analyzedProfile.targetAudience?.interests?.length ? (
                                        analyzedProfile.targetAudience.interests.map((interest, i) => (
                                            <span key={i} className="text-[10px] bg-[#28292A] text-gray-400 px-2 py-0.5 rounded border border-[#333]">
                                                {interest}
                                            </span>
                                        ))
                                    ) : <span className="text-xs text-gray-600">No data</span>}
                                </div>
                            </div>

                            <div>
                                <span className="text-[10px] text-gray-500 block mb-1">Pain Points</span>
                                <ul className="list-disc list-inside text-xs text-gray-400 space-y-0.5">
                                    {analyzedProfile.targetAudience?.painPoints?.length ? (
                                        analyzedProfile.targetAudience.painPoints.map((point, i) => (
                                            <li key={i} className="truncate">{point}</li>
                                        ))
                                    ) : <li className="text-gray-600 list-none">No data</li>}
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <span className="text-[10px] uppercase tracking-wider text-gray-500 block mb-1">Visual Style</span>
                            <p className="text-gray-300 text-xs">{analyzedProfile.visualStyle}</p>
                        </div>
                        <div>
                            <span className="text-[10px] uppercase tracking-wider text-gray-500 block mb-1">Brand Colors</span>
                            <div className="flex flex-wrap gap-2">
                                {analyzedProfile.colors.map((color, idx) => (
                                <div key={idx} className="w-5 h-5 rounded-full border border-white/10 shadow-sm" style={{ backgroundColor: color }} title={color}></div>
                                ))}
                            </div>
                        </div>
                    </div>
                    
                    {/* Key Visual Elements (New) */}
                    <div>
                        <span className="text-[10px] uppercase tracking-wider text-gray-500 block mb-1">Key Visual Elements</span>
                        <div className="bg-[#131314] p-3 rounded-lg border border-[#444746] flex flex-wrap gap-2">
                             {analyzedProfile.keyElements?.length ? (
                                analyzedProfile.keyElements.map((el, i) => (
                                    <span key={i} className="text-xs text-yellow-500 bg-yellow-500/10 px-2 py-1 rounded border border-yellow-500/20">
                                        {el}
                                    </span>
                                ))
                             ) : <span className="text-xs text-gray-500 italic">No key elements detected</span>}
                        </div>
                    </div>

                  </div>

                  {/* Right Column: Visual Assets */}
                  <div className="flex flex-col items-center bg-[#131314] rounded-lg p-4 border border-[#444746]">
                      <span className="text-[10px] uppercase tracking-wider text-gray-500 mb-3 w-full text-center">AI Brand Representative</span>
                      
                      {analyzedProfile.avatarUrl ? (
                          <div className="relative w-full aspect-square max-w-[220px] rounded-lg border border-[#444746] shadow-2xl overflow-hidden group mb-3">
                             <img src={analyzedProfile.avatarUrl} alt="Brand Avatar" className="w-full h-full object-cover" />
                             <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-60"></div>
                             <div className="absolute bottom-3 left-3 text-white text-xs font-medium">
                                Generated Persona
                             </div>
                          </div>
                      ) : (
                          <div className="w-full aspect-square max-w-[220px] rounded-lg bg-[#28292A] flex items-center justify-center text-gray-500 text-xs text-center p-4 mb-3">
                              No Avatar Generated
                          </div>
                      )}
                      <p className="text-[10px] text-gray-500 text-center px-2">
                          This realistic human avatar is tailored to the {analyzedProfile.industry} industry and will represent your brand in generated content.
                      </p>
                  </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-6 border-t border-[#444746] flex justify-end gap-3 bg-[#1E1F20] sticky bottom-0 rounded-b-2xl">
          <button 
            onClick={onClose} 
            className="px-5 py-2 rounded-full text-gray-300 hover:bg-[#333] transition-colors font-medium"
          >
            Cancel
          </button>
          <button 
            onClick={handleConfirm}
            disabled={!analyzedProfile}
            className="px-6 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-blue-600/20"
          >
            Save Analysis
          </button>
        </div>

      </div>
    </div>
  );
};
