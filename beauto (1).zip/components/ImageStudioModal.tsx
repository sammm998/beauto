import React, { useState } from 'react';
import { editImage } from '../services/genai';
import { MagicWandIcon, RefreshIcon, SaveIcon, XIcon, SparklesIcon } from './Icons';

interface ImageStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  originalImage: string;
  onSave: (newImage: string) => void;
}

export const ImageStudioModal: React.FC<ImageStudioModalProps> = ({ isOpen, onClose, originalImage, onSave }) => {
  const [prompt, setPrompt] = useState('');
  const [currentImage, setCurrentImage] = useState(originalImage);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setIsProcessing(true);
    setError(null);
    try {
      // Use the image that is currently most relevant (either original or last generated)
      const sourceImage = generatedImage || currentImage;
      const result = await editImage(sourceImage, prompt);
      
      if (result) {
        setGeneratedImage(result);
      } else {
        setError("Could not generate image. Try a different prompt.");
      }
    } catch (e) {
      setError("Error editing image. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSave = () => {
    if (generatedImage) {
      onSave(generatedImage);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-md">
      <div className="w-full h-full md:w-[90vw] md:h-[90vh] bg-[#1E1F20] md:rounded-2xl flex flex-col overflow-hidden shadow-2xl border border-[#444746]">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-[#444746] bg-[#28292A]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-500/20 rounded-lg">
              <MagicWandIcon className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <h2 className="text-white font-medium text-lg">Image Studio</h2>
              <p className="text-xs text-gray-400">Refine your image with AI</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-[#333] rounded-full text-gray-400 transition-colors">
            <XIcon className="w-6 h-6" />
          </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            
            {/* Canvas Area */}
            <div className="flex-1 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')] bg-[#131314] relative flex items-center justify-center p-8">
               <div className="relative max-w-full max-h-full flex gap-4">
                  {/* Original/Previous Image (Hidden on mobile if generated exists to save space, or side by side) */}
                  <div className={`relative rounded-xl overflow-hidden shadow-2xl border border-[#444746] transition-all duration-500 ${generatedImage ? 'hidden md:block opacity-50 scale-95' : 'scale-100'}`}>
                      <img src={currentImage} alt="Original" className="max-h-[70vh] object-contain" />
                      <div className="absolute top-2 left-2 bg-black/60 px-2 py-1 rounded text-[10px] text-white backdrop-blur-sm">Original</div>
                  </div>

                  {/* Generated Result */}
                  {generatedImage && (
                    <div className="relative rounded-xl overflow-hidden shadow-2xl border border-purple-500/50 scale-100 z-10">
                        <img src={generatedImage} alt="Generated" className="max-h-[70vh] object-contain" />
                        <div className="absolute top-2 left-2 bg-purple-600/80 px-2 py-1 rounded text-[10px] text-white backdrop-blur-sm flex items-center gap-1">
                            <SparklesIcon className="w-3 h-3" />
                            New Version
                        </div>
                    </div>
                  )}

                  {isProcessing && (
                      <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/60 backdrop-blur-sm rounded-xl">
                          <div className="flex flex-col items-center gap-3">
                              <div className="w-10 h-10 border-3 border-purple-500 border-t-transparent rounded-full animate-spin" />
                              <span className="text-purple-300 font-medium animate-pulse">Refining Image...</span>
                          </div>
                      </div>
                  )}
               </div>
            </div>

            {/* Sidebar Controls */}
            <div className="w-full md:w-80 bg-[#1E1F20] border-t md:border-t-0 md:border-l border-[#444746] p-6 flex flex-col gap-6">
                
                <div className="space-y-4">
                    <label className="text-sm font-medium text-gray-300">Refinement Prompt</label>
                    <textarea 
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="Describe changes (e.g., 'Make it sunset', 'Add a neon sign', 'Change background to office')..."
                        className="w-full bg-[#131314] border border-[#444746] rounded-xl p-3 text-sm text-white focus:outline-none focus:border-purple-500 resize-none h-32 placeholder-gray-500"
                    />
                    <button 
                        onClick={handleGenerate}
                        disabled={!prompt.trim() || isProcessing}
                        className="w-full py-3 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white rounded-xl font-medium shadow-lg shadow-purple-900/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-all"
                    >
                        {isProcessing ? <RefreshIcon className="w-4 h-4 animate-spin" /> : <SparklesIcon className="w-4 h-4" />}
                        {generatedImage ? 'Regenerate' : 'Generate Edit'}
                    </button>
                    {error && <p className="text-red-400 text-xs mt-2">{error}</p>}
                </div>

                <div className="mt-auto border-t border-[#444746] pt-6 space-y-3">
                     <p className="text-xs text-gray-500 leading-relaxed">
                        Use the Gemini Image Editor to tweak details, change lighting, or add elements. The AI will try to preserve the essence of the original image.
                     </p>
                     
                     <div className="flex gap-3">
                         <button 
                            onClick={onClose}
                            className="flex-1 py-2.5 rounded-lg border border-[#444746] hover:bg-[#333] text-gray-300 text-sm transition-colors"
                         >
                            Cancel
                         </button>
                         <button 
                            onClick={handleSave}
                            disabled={!generatedImage}
                            className="flex-1 py-2.5 rounded-lg bg-green-600 hover:bg-green-500 disabled:bg-[#333] disabled:text-gray-600 text-white text-sm font-medium transition-colors flex items-center justify-center gap-2"
                         >
                            <SaveIcon className="w-4 h-4" />
                            Save Changes
                         </button>
                     </div>
                </div>

            </div>
        </div>
      </div>
    </div>
  );
};
