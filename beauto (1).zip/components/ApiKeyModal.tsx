import React from 'react';
import { AlertCircle } from './Icons';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectKey: () => void;
  error?: string;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ isOpen, onClose, onSelectKey, error }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="bg-[#1E1F20] rounded-2xl p-6 max-w-md w-full border border-[#444746] shadow-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-blue-500/20 rounded-full">
            <AlertCircle className="text-blue-400 w-6 h-6" />
          </div>
          <h2 className="text-xl font-google font-medium text-white">Veo Video Generation</h2>
        </div>
        
        <p className="text-gray-300 mb-6 leading-relaxed">
          To generate high-quality videos with Veo, you need to select a paid project API key from Google Cloud. 
          <br/><br/>
          <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noreferrer" className="text-blue-400 hover:underline">
            Learn more about billing
          </a>
        </p>

        {error && (
           <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-3 mb-4 text-red-300 text-sm">
             {error}
           </div>
        )}

        <div className="flex justify-end gap-3">
          <button 
            onClick={onClose}
            className="px-4 py-2 rounded-full text-gray-300 hover:bg-[#333] transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={onSelectKey}
            className="px-6 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-white font-medium transition-all"
          >
            Select API Key
          </button>
        </div>
      </div>
    </div>
  );
};
