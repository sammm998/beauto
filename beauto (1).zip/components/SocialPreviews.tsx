import React from 'react';
import { 
    InstagramIcon, 
    FacebookIcon, 
    LinkedinIcon, 
    VideoIcon, 
    ImageIcon, 
    SparklesIcon, 
    GlobeIcon,
    EditIcon
} from './Icons';
import ReactMarkdown from 'react-markdown';

interface PreviewProps {
    platform: string;
    imageUrl?: string;
    videoUrl?: string;
    caption: string;
    profileName: string;
    profileImage?: string;
    onEdit?: () => void;
}

const InteractionBar = ({ likes = "1,243", comments = "86", shares = "24" }) => (
    <div className="flex items-center justify-between py-3 border-t border-gray-100 dark:border-gray-800">
        <div className="flex items-center gap-4">
            <button className="text-gray-600 dark:text-gray-300 hover:text-red-500 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
            </button>
            <button className="text-gray-600 dark:text-gray-300 hover:text-blue-500 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            </button>
            <button className="text-gray-600 dark:text-gray-300 hover:text-green-500 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/></svg>
            </button>
        </div>
        <button className="text-gray-600 dark:text-gray-300 hover:text-yellow-500 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/></svg>
        </button>
    </div>
);

const EditOverlay = ({ onEdit }: { onEdit?: () => void }) => {
    if (!onEdit) return null;
    return (
        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
            <button 
                onClick={(e) => { e.stopPropagation(); onEdit(); }}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-black/70 hover:bg-black/90 text-white rounded-full backdrop-blur-md text-xs font-medium border border-white/20 shadow-lg transition-transform hover:scale-105"
            >
                <EditIcon className="w-3.5 h-3.5" />
                Edit in Studio
            </button>
        </div>
    );
};

export const InstagramPreview: React.FC<PreviewProps> = ({ imageUrl, videoUrl, caption, profileName, profileImage, onEdit }) => (
    <div className="bg-white dark:bg-black border border-gray-200 dark:border-[#262626] rounded-xl max-w-sm w-full mx-auto shadow-sm overflow-hidden font-sans">
        {/* Header */}
        <div className="flex items-center justify-between p-3">
            <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-yellow-400 to-purple-600 p-[2px]">
                   <div className="w-full h-full rounded-full bg-white dark:bg-black border-2 border-transparent overflow-hidden">
                       {profileImage ? <img src={profileImage} className="w-full h-full object-cover" alt="Profile" /> : <div className="w-full h-full bg-gray-200" />}
                   </div>
                </div>
                <span className="text-sm font-semibold text-black dark:text-white">{profileName}</span>
            </div>
            <button className="text-black dark:text-white">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>
            </button>
        </div>

        {/* Content */}
        <div className="relative aspect-square bg-gray-100 dark:bg-[#121212] flex items-center justify-center overflow-hidden group">
            {videoUrl ? (
                <video src={videoUrl} className="w-full h-full object-cover" controls autoPlay muted loop />
            ) : imageUrl ? (
                <>
                    <img src={imageUrl} alt="Post Content" className="w-full h-full object-cover" />
                    <EditOverlay onEdit={onEdit} />
                </>
            ) : (
                <div className="text-gray-400 flex flex-col items-center">
                    <ImageIcon className="w-8 h-8 mb-2" />
                    <span className="text-xs">Image Generating...</span>
                </div>
            )}
        </div>

        {/* Interaction */}
        <div className="p-3">
            <InteractionBar />
            <div className="text-sm font-semibold mb-1 text-black dark:text-white">1,243 likes</div>
            <div className="text-sm text-black dark:text-white">
                <span className="font-semibold mr-2">{profileName}</span>
                <span className="text-sm leading-tight text-black dark:text-white opacity-90"><ReactMarkdown>{caption}</ReactMarkdown></span>
            </div>
        </div>
    </div>
);

export const FacebookPreview: React.FC<PreviewProps> = ({ imageUrl, videoUrl, caption, profileName, profileImage, onEdit }) => (
    <div className="bg-white dark:bg-[#242526] border border-gray-200 dark:border-[#3E4042] rounded-xl max-w-md w-full mx-auto shadow-sm overflow-hidden font-sans">
        {/* Header */}
        <div className="p-3 flex items-center gap-2">
             <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden">
                {profileImage ? <img src={profileImage} className="w-full h-full object-cover" alt="Profile" /> : null}
             </div>
             <div>
                 <h4 className="text-sm font-semibold text-black dark:text-[#E4E6EB]">{profileName}</h4>
                 <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-[#B0B3B8]">
                     <span>Just now</span>
                     <span>•</span>
                     <GlobeIcon className="w-3 h-3" />
                 </div>
             </div>
        </div>

        {/* Caption */}
        <div className="px-3 pb-3 text-sm text-black dark:text-[#E4E6EB] leading-normal">
             <ReactMarkdown>{caption}</ReactMarkdown>
        </div>

        {/* Media */}
        <div className="relative w-full bg-black flex items-center justify-center overflow-hidden group">
             {videoUrl ? (
                 <video src={videoUrl} className="w-full max-h-[500px]" controls autoPlay muted loop />
             ) : imageUrl ? (
                <>
                 <img src={imageUrl} alt="Content" className="w-full h-auto object-cover" />
                 <EditOverlay onEdit={onEdit} />
                </>
             ) : (
                 <div className="h-64 flex items-center justify-center text-gray-500">
                     <ImageIcon className="w-8 h-8" />
                 </div>
             )}
        </div>
        
        {/* Interaction Footer */}
        <div className="px-3 py-2 border-t border-gray-200 dark:border-[#3E4042]">
             <div className="flex justify-between text-gray-500 dark:text-[#B0B3B8] text-xs py-2">
                 <span>👍 ❤️ 243</span>
                 <span>54 Comments</span>
             </div>
             <div className="flex justify-between border-t border-gray-200 dark:border-[#3E4042] pt-2">
                 <button className="flex-1 flex items-center justify-center gap-2 py-1 hover:bg-gray-100 dark:hover:bg-[#3A3B3C] rounded-md transition-colors text-gray-600 dark:text-[#B0B3B8] font-medium text-sm">
                     <span>Like</span>
                 </button>
                 <button className="flex-1 flex items-center justify-center gap-2 py-1 hover:bg-gray-100 dark:hover:bg-[#3A3B3C] rounded-md transition-colors text-gray-600 dark:text-[#B0B3B8] font-medium text-sm">
                     <span>Comment</span>
                 </button>
                 <button className="flex-1 flex items-center justify-center gap-2 py-1 hover:bg-gray-100 dark:hover:bg-[#3A3B3C] rounded-md transition-colors text-gray-600 dark:text-[#B0B3B8] font-medium text-sm">
                     <span>Share</span>
                 </button>
             </div>
        </div>
    </div>
);

export const LinkedInPreview: React.FC<PreviewProps> = ({ imageUrl, videoUrl, caption, profileName, profileImage, onEdit }) => (
    <div className="bg-white dark:bg-[#1D2226] border border-gray-200 dark:border-gray-700 rounded-lg max-w-md w-full mx-auto shadow-sm overflow-hidden font-sans">
        {/* Header */}
        <div className="p-3 flex gap-3">
             <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden border border-gray-100">
                {profileImage ? <img src={profileImage} className="w-full h-full object-cover" alt="Profile" /> : null}
             </div>
             <div>
                 <h4 className="text-sm font-semibold text-black dark:text-white leading-tight">{profileName}</h4>
                 <p className="text-xs text-gray-500 dark:text-gray-400">Company • Internet</p>
                 <div className="flex items-center gap-1 text-xs text-gray-400 mt-1">
                     <span>1d • </span>
                     <GlobeIcon className="w-3 h-3" />
                 </div>
             </div>
        </div>

        {/* Caption */}
        <div className="px-3 pb-3 text-sm text-black dark:text-white leading-relaxed">
            <ReactMarkdown>{caption}</ReactMarkdown>
        </div>

        {/* Media */}
        <div className="relative w-full bg-gray-100 dark:bg-black group">
             {videoUrl ? (
                 <video src={videoUrl} className="w-full h-auto" controls autoPlay muted loop />
             ) : imageUrl ? (
                <>
                 <img src={imageUrl} alt="Content" className="w-full h-auto object-cover" />
                 <EditOverlay onEdit={onEdit} />
                </>
             ) : null}
        </div>

        {/* Interaction */}
        <div className="px-3 py-2">
             <div className="flex items-center gap-4 border-t border-gray-200 dark:border-gray-700 pt-2">
                 <button className="flex flex-col items-center gap-1 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 p-2 rounded-md">
                     <span className="text-xs font-medium">Like</span>
                 </button>
                 <button className="flex flex-col items-center gap-1 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 p-2 rounded-md">
                     <span className="text-xs font-medium">Comment</span>
                 </button>
                 <button className="flex flex-col items-center gap-1 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 p-2 rounded-md">
                     <span className="text-xs font-medium">Repost</span>
                 </button>
                 <button className="flex flex-col items-center gap-1 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 p-2 rounded-md">
                     <span className="text-xs font-medium">Send</span>
                 </button>
             </div>
        </div>
    </div>
);

export const TikTokPreview: React.FC<PreviewProps> = ({ videoUrl, imageUrl, caption, profileName, profileImage }) => (
    <div className="relative bg-black rounded-2xl max-w-[320px] w-full mx-auto aspect-[9/16] overflow-hidden shadow-lg border border-gray-800">
         {/* Video/Image Background */}
         <div className="absolute inset-0 bg-gray-900 flex items-center justify-center">
             {videoUrl ? (
                 <video src={videoUrl} className="w-full h-full object-cover" autoPlay muted loop playsInline />
             ) : imageUrl ? (
                <div className="relative w-full h-full">
                     <img src={imageUrl} alt="Content" className="w-full h-full object-cover opacity-80" />
                     <div className="absolute inset-0 flex items-center justify-center">
                         <span className="bg-black/50 text-white px-3 py-1 rounded-full text-xs backdrop-blur-sm">Image Preview</span>
                     </div>
                </div>
             ) : (
                <div className="flex flex-col items-center text-gray-500">
                     <VideoIcon className="w-12 h-12 mb-2 opacity-50" />
                </div>
             )}
         </div>
 
         {/* UI Overlay */}
         <div className="absolute inset-0 flex flex-col justify-between p-4 bg-gradient-to-b from-black/30 via-transparent to-black/60 pointer-events-none">
             {/* Top Bar */}
             <div className="flex justify-center pt-2">
                 <div className="text-white font-semibold text-sm drop-shadow-md">Following | <span className="font-bold">For You</span></div>
             </div>
 
             {/* Right Sidebar Actions */}
             <div className="absolute right-2 bottom-20 flex flex-col items-center gap-4 pointer-events-auto">
                 <div className="relative">
                     <div className="w-10 h-10 rounded-full border border-white overflow-hidden bg-white">
                         {profileImage ? <img src={profileImage} className="w-full h-full object-cover" alt="Profile" /> : null}
                     </div>
                     <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-red-500 rounded-full p-0.5">
                         <svg width="10" height="10" viewBox="0 0 24 24" fill="white"><path d="M12 5v14M5 12h14" stroke="white" strokeWidth="4"/></svg>
                     </div>
                 </div>
                 <div className="flex flex-col items-center">
                     <div className="p-2 bg-white/10 rounded-full backdrop-blur-sm"><svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg></div>
                     <span className="text-white text-xs font-semibold drop-shadow-md mt-1">84.2K</span>
                 </div>
                 <div className="flex flex-col items-center">
                    <div className="p-2 bg-white/10 rounded-full backdrop-blur-sm"><svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg></div>
                    <span className="text-white text-xs font-semibold drop-shadow-md mt-1">1024</span>
                 </div>
                 <div className="flex flex-col items-center">
                    <div className="p-2 bg-white/10 rounded-full backdrop-blur-sm"><svg width="24" height="24" viewBox="0 0 24 24" fill="white"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" x2="12" y1="2" y2="15"/></svg></div>
                    <span className="text-white text-xs font-semibold drop-shadow-md mt-1">Share</span>
                 </div>
                 {/* Rotating Music Disc */}
                 <div className="w-10 h-10 rounded-full bg-black border-[3px] border-gray-800 flex items-center justify-center animate-[spin_4s_linear_infinite] mt-2">
                     <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-gray-700 to-gray-900"></div>
                 </div>
             </div>
 
             {/* Bottom Details */}
             <div className="mb-2 mr-16">
                 <h3 className="text-white font-bold text-sm drop-shadow-md mb-1">@{profileName.replace(/\s/g, '').toLowerCase()}</h3>
                 <div className="text-white text-xs leading-snug drop-shadow-md line-clamp-2">
                     <ReactMarkdown>{caption}</ReactMarkdown>
                 </div>
                 <div className="flex items-center gap-2 mt-2">
                     <svg width="12" height="12" viewBox="0 0 24 24" fill="white"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>
                     <div className="text-white text-xs font-medium overflow-hidden whitespace-nowrap w-32">
                         <div className="animate-[marquee_5s_linear_infinite]">Original Sound - {profileName}</div>
                     </div>
                 </div>
             </div>
         </div>
    </div>
);

export const PinterestPreview: React.FC<PreviewProps> = ({ imageUrl, videoUrl, caption, profileName, profileImage, onEdit }) => (
    <div className="bg-white dark:bg-[#121212] rounded-2xl max-w-[280px] w-full mx-auto shadow-md overflow-hidden font-sans border border-gray-100 dark:border-gray-800">
         <div className="relative group">
             {videoUrl ? (
                  <video src={videoUrl} className="w-full h-auto rounded-t-2xl" controls autoPlay muted loop />
             ) : imageUrl ? (
                <>
                 <img src={imageUrl} alt="Pin" className="w-full h-auto rounded-t-2xl" />
                 <EditOverlay onEdit={onEdit} />
                </>
             ) : null}
             <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
                 <button className="bg-red-600 text-white text-sm font-bold px-4 py-2 rounded-full shadow-lg">Save</button>
             </div>
         </div>
         <div className="p-3">
             <div className="flex justify-between items-start">
                 <p className="text-sm font-medium text-black dark:text-white line-clamp-2 leading-tight">
                    <ReactMarkdown>{caption.split(' ').slice(0, 10).join(' ') + '...'}</ReactMarkdown>
                 </p>
                 <button className="text-gray-500 hover:bg-gray-100 rounded-full p-1"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/><circle cx="5" cy="12" r="2"/></svg></button>
             </div>
             <div className="flex items-center gap-2 mt-2">
                 <div className="w-6 h-6 rounded-full bg-gray-200 overflow-hidden">
                     {profileImage ? <img src={profileImage} className="w-full h-full object-cover" alt="Profile" /> : null}
                 </div>
                 <span className="text-xs text-gray-700 dark:text-gray-300">{profileName}</span>
             </div>
         </div>
    </div>
);

export const SocialPreview: React.FC<PreviewProps> = (props) => {
    switch(props.platform) {
        case 'Instagram': return <InstagramPreview {...props} />;
        case 'TikTok': return <TikTokPreview {...props} />;
        case 'Facebook': return <FacebookPreview {...props} />;
        case 'LinkedIn': return <LinkedInPreview {...props} />;
        case 'Pinterest': return <PinterestPreview {...props} />;
        default: return <InstagramPreview {...props} />;
    }
}
