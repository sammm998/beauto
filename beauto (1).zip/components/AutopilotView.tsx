import React, { useState } from 'react';
import { BrandProfile, CalendarPost, Platform, ContentType, ContentTheme } from '../types';
import { generateContentCalendar, generateImage, generateVideo } from '../services/genai';
import { RobotIcon, SparklesIcon, VideoIcon, ImageIcon, CalendarIcon, CheckCircle, RefreshIcon, XIcon } from './Icons';
import { SocialPreview } from './SocialPreviews';

interface AutopilotViewProps {
  brandProfile?: BrandProfile;
}

const THEMES: { id: ContentTheme; label: string; description: string; color: string }[] = [
    { 
        id: 'Cinematic', 
        label: 'Cinematic & High-End', 
        description: 'Focus on dramatic lighting, storytelling, and premium production value. Perfect for luxury brands.', 
        color: 'from-amber-700 to-orange-900' 
    },
    { 
        id: 'Educational', 
        label: 'Educational & Value', 
        description: 'Establish authority with tips, how-tos, and industry insights. Best for B2B and coaches.', 
        color: 'from-blue-700 to-indigo-900' 
    },
    { 
        id: 'Viral', 
        label: 'Fun & Viral Trends', 
        description: 'Lighthearted, relatable content jumping on current social trends. High engagement potential.', 
        color: 'from-pink-600 to-rose-900' 
    },
    { 
        id: 'Product', 
        label: 'Product Showcase', 
        description: 'Clean, detailed focus on your products/services features and benefits. Sales driven.', 
        color: 'from-emerald-700 to-green-900' 
    },
    { 
        id: 'BehindTheScenes', 
        label: 'Behind The Scenes', 
        description: 'Authentic look at your company culture, team, and process. Builds trust.', 
        color: 'from-purple-700 to-violet-900' 
    },
    { 
        id: 'Minimalist', 
        label: 'Minimalist Aesthetic', 
        description: 'Clean lines, plenty of whitespace, and simple typography. Modern and sleek.', 
        color: 'from-gray-700 to-gray-900' 
    }
];

export const AutopilotView: React.FC<AutopilotViewProps> = ({ brandProfile }) => {
  const [step, setStep] = useState<'config' | 'calendar'>('config');
  const [postsPerWeek, setPostsPerWeek] = useState(3);
  const [videoRatio, setVideoRatio] = useState(50); // percentage
  const [selectedTheme, setSelectedTheme] = useState<ContentTheme | null>(null);
  
  const [isGeneratingPlan, setIsGeneratingPlan] = useState(false);
  const [calendarPosts, setCalendarPosts] = useState<CalendarPost[]>([]);
  const [selectedPost, setSelectedPost] = useState<CalendarPost | null>(null);
  const [generatingMediaFor, setGeneratingMediaFor] = useState<string | null>(null);

  if (!brandProfile) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <RobotIcon className="w-16 h-16 text-gray-500 mb-4" />
        <h2 className="text-2xl font-bold text-gray-300 mb-2">Autopilot Unavailable</h2>
        <p className="text-gray-500 max-w-md">
          You need to configure your Brand Profile in Settings before enabling Autopilot. The AI needs to know your brand to plan for you.
        </p>
      </div>
    );
  }

  const handleGeneratePlan = async () => {
    if(!selectedTheme) return;
    setIsGeneratingPlan(true);
    try {
      const posts = await generateContentCalendar(
        brandProfile,
        30, // Plan for 30 days
        postsPerWeek,
        videoRatio / 100,
        selectedTheme
      );
      setCalendarPosts(posts);
      setStep('calendar');
    } catch (e) {
      console.error(e);
    } finally {
      setIsGeneratingPlan(false);
    }
  };

  const handleGenerateMedia = async (post: CalendarPost) => {
    setGeneratingMediaFor(post.id);
    try {
      let url: string | null = null;
      if (post.contentType === ContentType.Reel) {
        url = await generateVideo(post.visualPrompt, brandProfile);
      } else {
        url = await generateImage(post.visualPrompt, brandProfile);
      }

      if (url) {
        setCalendarPosts(prev => prev.map(p => 
          p.id === post.id 
            ? { ...p, mediaUrl: url, status: 'ready' } 
            : p
        ));
        // Update selected post view if open
        if (selectedPost?.id === post.id) {
             setSelectedPost(prev => prev ? ({ ...prev, mediaUrl: url, status: 'ready' }) : null);
        }
      }
    } catch (e) {
      console.error("Media generation failed", e);
    } finally {
      setGeneratingMediaFor(null);
    }
  };

  // Helper to group posts by date for the calendar grid
  const postsByDate = calendarPosts.reduce((acc, post) => {
    const dateKey = post.date;
    if (!acc[dateKey]) acc[dateKey] = [];
    acc[dateKey].push(post);
    return acc;
  }, {} as Record<string, CalendarPost[]>);

  // Generate 30 days grid
  const today = new Date();
  const calendarDays = Array.from({ length: 30 }, (_, i) => {
    const d = new Date();
    d.setDate(today.getDate() + i);
    return d.toISOString().split('T')[0];
  });

  // --- WIZARD VIEW ---
  if (step === 'config') {
      return (
          <div className="flex flex-col h-full bg-[#131314] text-white overflow-y-auto p-8 max-w-5xl mx-auto w-full">
               <div className="mb-10 text-center">
                   <div className="w-16 h-16 bg-purple-500/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                       <RobotIcon className="w-8 h-8 text-purple-400" />
                   </div>
                   <h1 className="text-3xl font-google font-medium mb-2">Configure Autopilot</h1>
                   <p className="text-gray-400">Choose a strategy and frequency for your content calendar.</p>
               </div>

               {/* Step 1: Volume */}
               <div className="mb-12">
                   <h3 className="text-sm font-bold uppercase tracking-wider text-gray-500 mb-6">1. Content Frequency</h3>
                   <div className="bg-[#1E1F20] border border-[#444746] rounded-xl p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
                       <div className="space-y-4">
                            <label className="text-sm font-medium text-gray-300 flex justify-between">
                                <span>Posts per Week</span>
                                <span className="text-purple-400 font-bold">{postsPerWeek}</span>
                            </label>
                            <input 
                                type="range" 
                                min="1" 
                                max="7" 
                                value={postsPerWeek} 
                                onChange={(e) => setPostsPerWeek(parseInt(e.target.value))}
                                className="w-full accent-purple-500 h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer"
                            />
                            <p className="text-xs text-gray-500">How many times per week should the brand post?</p>
                       </div>
                       <div className="space-y-4">
                            <label className="text-sm font-medium text-gray-300 flex justify-between">
                                <span>Format Mix</span>
                                <span className="text-pink-400 font-bold">{videoRatio}% Video</span>
                            </label>
                            <input 
                                type="range" 
                                min="0" 
                                max="100" 
                                step="10"
                                value={videoRatio} 
                                onChange={(e) => setVideoRatio(parseInt(e.target.value))}
                                className="w-full accent-pink-500 h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer"
                            />
                            <p className="text-xs text-gray-500">Balance between static images and video Reels.</p>
                       </div>
                   </div>
               </div>

               {/* Step 2: Theme/Strategy */}
               <div className="mb-12">
                   <h3 className="text-sm font-bold uppercase tracking-wider text-gray-500 mb-6">2. Select Strategy Theme</h3>
                   <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                       {THEMES.map(theme => (
                           <button
                                key={theme.id}
                                onClick={() => setSelectedTheme(theme.id)}
                                className={`relative group p-6 rounded-xl border text-left transition-all duration-300 overflow-hidden ${
                                    selectedTheme === theme.id 
                                    ? 'border-white ring-1 ring-white shadow-2xl scale-[1.02]' 
                                    : 'border-[#444746] bg-[#1E1F20] hover:border-gray-500 hover:bg-[#28292A]'
                                }`}
                           >
                               <div className={`absolute inset-0 bg-gradient-to-br ${theme.color} opacity-0 group-hover:opacity-10 transition-opacity`} />
                               <div className={`absolute top-0 right-0 p-3 opacity-0 transition-opacity ${selectedTheme === theme.id ? 'opacity-100' : ''}`}>
                                   <CheckCircle className="w-6 h-6 text-white" />
                               </div>
                               
                               <h4 className="font-medium text-lg mb-2 relative z-10">{theme.label}</h4>
                               <p className="text-sm text-gray-400 leading-relaxed relative z-10">{theme.description}</p>
                           </button>
                       ))}
                   </div>
               </div>

               <button 
                  onClick={handleGeneratePlan}
                  disabled={!selectedTheme || isGeneratingPlan}
                  className="w-full md:w-auto mx-auto px-8 py-4 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-full font-medium text-lg shadow-lg shadow-purple-900/30 flex items-center justify-center gap-3 transition-transform active:scale-95"
               >
                   {isGeneratingPlan ? (
                       <>
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Generating Proposal...
                       </>
                   ) : (
                       <>
                        <SparklesIcon className="w-5 h-5" />
                        Generate Content Plan
                       </>
                   )}
               </button>
          </div>
      )
  }

  // --- CALENDAR VIEW ---
  return (
    <div className="flex flex-col h-full bg-[#131314] text-white">
      {/* Header / Config */}
      <div className="p-6 border-b border-[#444746] flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
           <div className="flex items-center gap-3 mb-1">
                <button onClick={() => setStep('config')} className="p-1 hover:bg-[#28292A] rounded-full">
                    <XIcon className="w-5 h-5 text-gray-500" />
                </button>
                <h1 className="text-xl font-google font-medium flex items-center gap-2">
                    <RobotIcon className="w-5 h-5 text-purple-400" />
                    Autopilot Calendar
                </h1>
           </div>
           <div className="flex items-center gap-3 ml-9">
                <span className="text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    {selectedTheme} Strategy
                </span>
                <span className="text-xs text-gray-500">
                    {postsPerWeek} posts/wk • {videoRatio}% Video
                </span>
           </div>
        </div>

        <button 
            onClick={handleGeneratePlan}
            disabled={isGeneratingPlan}
            className="px-4 py-2 bg-[#28292A] hover:bg-[#333] border border-[#444746] text-white rounded-lg font-medium text-sm transition-colors flex items-center gap-2"
        >
            {isGeneratingPlan ? <RefreshIcon className="w-4 h-4 animate-spin" /> : <RefreshIcon className="w-4 h-4" />}
            Regenerate
        </button>
      </div>

      {/* Main Content Area: Split View (Calendar Grid | Details) */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Calendar Grid */}
        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
            {calendarPosts.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center opacity-50">
                    <CalendarIcon className="w-24 h-24 text-gray-600 mb-4" />
                    <p className="text-gray-400">No plan generated.</p>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {calendarDays.map((dateStr) => {
                        const posts = postsByDate[dateStr] || [];
                        const dateObj = new Date(dateStr);
                        const isToday = dateStr === new Date().toISOString().split('T')[0];

                        return (
                            <div key={dateStr} className={`bg-[#1E1F20] border ${isToday ? 'border-purple-500/50' : 'border-[#444746]'} rounded-xl p-3 min-h-[140px] flex flex-col`}>
                                <div className="text-xs text-gray-500 font-medium mb-3 flex justify-between">
                                    <span>{dateObj.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</span>
                                    {isToday && <span className="text-purple-400">Today</span>}
                                </div>
                                
                                <div className="flex-1 space-y-2">
                                    {posts.map(post => (
                                        <button
                                            key={post.id}
                                            onClick={() => setSelectedPost(post)}
                                            className={`w-full text-left p-2 rounded-lg text-xs border transition-all flex items-center gap-2 ${
                                                selectedPost?.id === post.id 
                                                ? 'bg-purple-900/30 border-purple-500/50' 
                                                : 'bg-[#28292A] border-transparent hover:border-gray-600'
                                            }`}
                                        >
                                            {post.contentType === ContentType.Reel ? (
                                                <VideoIcon className="w-3 h-3 text-pink-400 shrink-0" />
                                            ) : (
                                                <ImageIcon className="w-3 h-3 text-blue-400 shrink-0" />
                                            )}
                                            <span className="truncate text-gray-300">{post.title}</span>
                                            {post.status === 'ready' && <CheckCircle className="w-3 h-3 text-green-500 ml-auto shrink-0" />}
                                        </button>
                                    ))}
                                    {posts.length === 0 && (
                                        <div className="h-full flex items-center justify-center text-[10px] text-gray-700 italic">
                                            No posts
                                        </div>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>

        {/* Right Detail Panel */}
        {selectedPost && (
            <div className="w-[400px] border-l border-[#444746] bg-[#1a1a1b] overflow-y-auto p-6 shadow-2xl z-10 flex flex-col animate-in slide-in-from-right-10 duration-200">
                <div className="flex items-center justify-between mb-6">
                    <h3 className="font-medium text-white flex items-center gap-2">
                        {selectedPost.contentType === ContentType.Reel ? <VideoIcon className="text-pink-400" /> : <ImageIcon className="text-blue-400" />}
                        {selectedPost.platform} Post
                    </h3>
                    <button onClick={() => setSelectedPost(null)} className="text-gray-500 hover:text-white">
                        <XIcon className="w-5 h-5" />
                    </button>
                </div>

                <div className="flex-1 space-y-6">
                    {/* Visual Preview */}
                    <div>
                        <h4 className="text-xs uppercase tracking-wider text-gray-500 mb-2">Visual Asset</h4>
                        <div className="rounded-xl overflow-hidden border border-[#444746] bg-[#131314] relative min-h-[200px] flex items-center justify-center">
                            {selectedPost.mediaUrl ? (
                                selectedPost.contentType === ContentType.Reel ? (
                                    <video src={selectedPost.mediaUrl} controls className="w-full h-auto" />
                                ) : (
                                    <img src={selectedPost.mediaUrl} className="w-full h-auto" alt="Generated" />
                                )
                            ) : (
                                <div className="text-center p-6">
                                    <p className="text-sm text-gray-400 mb-4">Content planned. Ready to generate media.</p>
                                    <button 
                                        onClick={() => handleGenerateMedia(selectedPost)}
                                        disabled={generatingMediaFor === selectedPost.id}
                                        className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-full text-xs font-medium transition-colors flex items-center justify-center gap-2 mx-auto"
                                    >
                                        {generatingMediaFor === selectedPost.id ? (
                                            <>
                                                <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                                Generating...
                                            </>
                                        ) : (
                                            <>
                                                <SparklesIcon className="w-3 h-3" />
                                                Generate {selectedPost.contentType === ContentType.Reel ? 'Video' : 'Image'}
                                            </>
                                        )}
                                    </button>
                                </div>
                            )}
                        </div>
                         {selectedPost.mediaUrl && (
                             <div className="mt-2 text-center">
                                 <SocialPreview 
                                    platform={selectedPost.platform}
                                    caption={selectedPost.caption}
                                    imageUrl={selectedPost.contentType === ContentType.Post ? selectedPost.mediaUrl : undefined}
                                    videoUrl={selectedPost.contentType === ContentType.Reel ? selectedPost.mediaUrl : undefined}
                                    profileName={brandProfile.name}
                                    profileImage={brandProfile.avatarUrl}
                                 />
                             </div>
                         )}
                    </div>

                    {/* Content Details */}
                    <div className="space-y-4">
                        <div>
                            <h4 className="text-xs uppercase tracking-wider text-gray-500 mb-1">Title</h4>
                            <p className="text-sm text-white">{selectedPost.title}</p>
                        </div>
                        <div>
                            <h4 className="text-xs uppercase tracking-wider text-gray-500 mb-1">Date</h4>
                            <p className="text-sm text-gray-300">{new Date(selectedPost.date).toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                        </div>
                        <div>
                            <h4 className="text-xs uppercase tracking-wider text-gray-500 mb-1">Visual Prompt</h4>
                            <p className="text-xs text-gray-400 italic bg-[#28292A] p-3 rounded-lg border border-[#444746]">{selectedPost.visualPrompt}</p>
                        </div>
                        <div>
                            <h4 className="text-xs uppercase tracking-wider text-gray-500 mb-1">Caption</h4>
                            <p className="text-sm text-gray-300 whitespace-pre-wrap leading-relaxed">{selectedPost.caption}</p>
                        </div>
                    </div>
                </div>
            </div>
        )}

      </div>
    </div>
  );
};