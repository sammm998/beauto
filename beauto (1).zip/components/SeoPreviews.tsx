import React from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { GlobeIcon } from './Icons';

interface SeoVisualizerProps {
    text: string;
}

export const SerpPreview: React.FC<{ text: string }> = ({ text }) => {
     // Attempt to extract a Title and Description for a SERP preview
    const titleMatch = text.match(/\*\*(?:Title Tag|Title|Meta Title):\*\*\s*(.*?)(?:\n|$)/i) || text.match(/^#\s+(.*?)$/m);
    const descMatch = text.match(/\*\*(?:Meta Description|Description):\*\*\s*(.*?)(?:\n|$)/i);
    const urlMatch = text.match(/https?:\/\/[^\s)]+/);

    const title = titleMatch ? titleMatch[1].trim() : "Brand Homepage - SEO Optimized";
    const description = descMatch ? descMatch[1].trim() : "Learn more about our services and offerings. We provide top-tier solutions for your needs.";
    const url = urlMatch ? urlMatch[0] : "https://www.example.com";
    
    // Only show if we found at least a title or description that looks like SEO data
    if (!titleMatch && !descMatch) return null;

    return (
        <div className="bg-white dark:bg-[#1E1F20] border border-gray-200 dark:border-[#444746] p-3 rounded-xl shadow-sm mb-4 font-sans max-w-md">
            <div className="flex items-center gap-2 mb-2 border-b border-gray-100 dark:border-[#333] pb-2">
                <GlobeIcon className="w-3 h-3 text-blue-500" />
                <span className="text-[10px] font-medium text-gray-500 uppercase tracking-wide">Google Search Preview</span>
            </div>
            <div>
                <div className="flex items-center gap-2 mb-1">
                    <div className="w-5 h-5 rounded-full bg-gray-100 dark:bg-[#333] flex items-center justify-center text-[8px] text-gray-500">
                        logo
                    </div>
                    <div className="flex flex-col">
                        <span className="text-[10px] text-gray-800 dark:text-gray-300">{new URL(url).hostname}</span>
                        <span className="text-[9px] text-gray-500 truncate max-w-[200px]">{url}</span>
                    </div>
                </div>
                <h3 className="text-sm text-[#1a0dab] dark:text-[#8ab4f8] hover:underline cursor-pointer font-medium truncate leading-tight mb-1">
                    {title}
                </h3>
                <p className="text-xs text-[#4d5156] dark:text-[#bdc1c6] leading-snug line-clamp-2">
                    {description}
                </p>
            </div>
        </div>
    );
}

export const SeoVisualizer: React.FC<SeoVisualizerProps> = ({ text }) => {
    return (
        <div className="flex flex-col gap-6 w-full">
            <SerpPreview text={text} />

            {/* Structured Report */}
            <div className="bg-white dark:bg-[#1E1F20] border border-gray-200 dark:border-[#444746] rounded-2xl p-6 overflow-hidden">
                <div className="prose dark:prose-invert max-w-none prose-sm md:prose-base prose-headings:font-google prose-a:text-blue-500 prose-img:rounded-xl">
                    <ReactMarkdown 
                        remarkPlugins={[remarkGfm]}
                        components={{
                            table: ({node, ...props}) => (
                                <div className="overflow-x-auto my-4 rounded-lg border border-gray-200 dark:border-[#444746]">
                                    <table className="min-w-full divide-y divide-gray-200 dark:divide-[#444746]" {...props} />
                                </div>
                            ),
                            thead: ({node, ...props}) => (
                                <thead className="bg-gray-50 dark:bg-[#28292A]" {...props} />
                            ),
                            th: ({node, ...props}) => (
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider" {...props} />
                            ),
                            td: ({node, ...props}) => (
                                <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300 border-t border-gray-200 dark:border-[#333]" {...props} />
                            )
                        }}
                    >
                        {text}
                    </ReactMarkdown>
                </div>
            </div>
        </div>
    );
};